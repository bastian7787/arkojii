import { format } from "date-fns";
import { id as localeId } from "date-fns/locale";
import { Calendar, Clock, User, DollarSign } from "lucide-react";

interface BookingSummaryCardProps {
  customerName: string;
  date: Date | undefined;
  startTime: string;
  endTime: string;
  totalPrice: number;
  compact?: boolean;
  shiftLabel?: string;
  durationHours?: number;
  hidePrice?: boolean;
}

export function BookingSummaryCard({
  customerName,
  date,
  startTime,
  endTime,
  totalPrice,
  compact = false,
  shiftLabel,
  durationHours,
  hidePrice = false,
}: BookingSummaryCardProps) {
  const displayDuration = durationHours ?? 6; // Default 6 hours for shift

  if (compact) {
    return (
      <div className="glass-card rounded-xl p-4 space-y-3">
        <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">
          Ringkasan
        </h3>
        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-primary" />
            <span>{customerName}</span>
          </div>
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-primary" />
            <span>
              {date ? format(date, "d MMMM yyyy", { locale: localeId }) : "-"}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-primary" />
            <span>
              {shiftLabel ? `${shiftLabel} (${startTime} - ${endTime})` : `${startTime} - ${endTime} (${displayDuration} jam)`}
            </span>
          </div>
        </div>
        {!hidePrice && (
          <div className="pt-3 border-t border-border">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Total</span>
              <span className="text-xl font-bold text-primary">
                Rp {totalPrice.toLocaleString("id-ID")}
              </span>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="glass-card rounded-2xl p-6 space-y-4">
      <h3 className="font-semibold gradient-primary bg-clip-text text-transparent">
        Detail Booking
      </h3>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-muted-foreground text-sm">
            <User className="w-4 h-4" />
            <span>Nama</span>
          </div>
          <p className="font-medium">{customerName}</p>
        </div>
        
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-muted-foreground text-sm">
            <Calendar className="w-4 h-4" />
            <span>Tanggal</span>
          </div>
          <p className="font-medium">
            {date ? format(date, "d MMMM yyyy", { locale: localeId }) : "-"}
          </p>
        </div>
        
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-muted-foreground text-sm">
            <Clock className="w-4 h-4" />
            <span>Waktu</span>
          </div>
          <p className="font-medium">
            {startTime} - {endTime}
          </p>
        </div>
        
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-muted-foreground text-sm">
            <DollarSign className="w-4 h-4" />
            <span>Durasi</span>
          </div>
          <p className="font-medium">{shiftLabel || `${displayDuration} jam`}</p>
        </div>
      </div>

      {!hidePrice && (
        <div className="pt-4 border-t border-border/50">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Pembayaran</p>
              <p className="text-xs text-muted-foreground">
                {shiftLabel ? "1 shift" : `${displayDuration} jam`}
              </p>
            </div>
            <p className="text-2xl font-bold gradient-primary bg-clip-text text-transparent">
              Rp {totalPrice.toLocaleString("id-ID")}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
