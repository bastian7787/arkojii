import { Check, FileText, CreditCard, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface BookingProgressProps {
  currentStep: "form" | "payment" | "success";
}

const steps = [
  { id: "form", label: "Detail Booking", icon: FileText },
  { id: "payment", label: "Pembayaran", icon: CreditCard },
  { id: "success", label: "Selesai", icon: CheckCircle2 },
];

export function BookingProgress({ currentStep }: BookingProgressProps) {
  const currentIndex = steps.findIndex((s) => s.id === currentStep);

  return (
    <div className="w-full max-w-lg mx-auto mb-8">
      <div className="flex items-center justify-between relative">
        {/* Progress Line */}
        <div className="absolute top-5 left-0 w-full h-0.5 bg-muted">
          <div
            className="h-full gradient-primary transition-all duration-500 ease-out"
            style={{
              width: `${(currentIndex / (steps.length - 1)) * 100}%`,
            }}
          />
        </div>

        {steps.map((step, index) => {
          const Icon = step.icon;
          const isCompleted = index < currentIndex;
          const isCurrent = index === currentIndex;

          return (
            <div
              key={step.id}
              className="relative flex flex-col items-center gap-2 z-10"
            >
              <div
                className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300",
                  isCompleted
                    ? "gradient-primary shadow-glow"
                    : isCurrent
                    ? "gradient-primary shadow-elevated animate-pulse"
                    : "bg-muted border-2 border-border"
                )}
              >
                {isCompleted ? (
                  <Check className="w-5 h-5 text-primary-foreground" />
                ) : (
                  <Icon
                    className={cn(
                      "w-5 h-5",
                      isCurrent ? "text-primary-foreground" : "text-muted-foreground"
                    )}
                  />
                )}
              </div>
              <span
                className={cn(
                  "text-xs font-medium whitespace-nowrap transition-colors",
                  isCurrent || isCompleted
                    ? "text-primary"
                    : "text-muted-foreground"
                )}
              >
                {step.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
