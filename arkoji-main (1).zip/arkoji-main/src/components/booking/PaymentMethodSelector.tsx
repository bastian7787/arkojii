import { cn } from "@/lib/utils";
import { Check, Building2, Wallet, Smartphone } from "lucide-react";

export interface PaymentSetting {
  id: string;
  payment_type: string;
  payment_name: string;
  account_number: string | null;
  account_holder: string | null;
}

interface PaymentMethodSelectorProps {
  paymentSettings: PaymentSetting[];
  selectedPayment: string;
  onSelect: (id: string) => void;
}

const getPaymentIcon = (type: string) => {
  if (type === "bank_transfer") return Building2;
  if (type === "e_wallet") return Smartphone;
  return Wallet;
};

const getPaymentTypeLabel = (type: string, name: string) => {
  if (type === "bank_transfer") return "Transfer ke rekening bank";
  if (type === "e_wallet") {
    if (name.toLowerCase().includes("shopee")) return "Transfer ke ShopeePay";
    if (name.toLowerCase().includes("gopay")) return "Transfer ke GoPay";
    return "Transfer ke E-Wallet";
  }
  return "Metode Pembayaran";
};

const getPaymentDetailTitle = (type: string, name: string) => {
  if (type === "bank_transfer") return "Detail Transfer Bank";
  if (type === "e_wallet") return `Detail ${name}`;
  return "Detail Pembayaran";
};

const getAccountLabel = (type: string) => {
  if (type === "bank_transfer") return "Nomor Rekening";
  if (type === "e_wallet") return "Nomor Telepon";
  return "Nomor";
};

const getPaymentColor = (name: string) => {
  const lowerName = name.toLowerCase();
  if (lowerName.includes("bca")) return "from-blue-600 to-blue-800";
  if (lowerName.includes("shopee")) return "from-orange-500 to-red-500";
  if (lowerName.includes("gopay")) return "from-green-500 to-teal-600";
  return "from-primary to-secondary";
};

export function PaymentMethodSelector({
  paymentSettings,
  selectedPayment,
  onSelect,
}: PaymentMethodSelectorProps) {
  const selectedInfo = paymentSettings.find((p) => p.id === selectedPayment);
  const Icon = selectedInfo ? getPaymentIcon(selectedInfo.payment_type) : Wallet;

  return (
    <div className="space-y-4">
      <div className="grid gap-3">
        {paymentSettings.map((payment) => {
          const PaymentIcon = getPaymentIcon(payment.payment_type);
          const isSelected = selectedPayment === payment.id;
          const gradientColor = getPaymentColor(payment.payment_name);

          return (
            <button
              key={payment.id}
              type="button"
              onClick={() => onSelect(payment.id)}
              className={cn(
                "relative p-4 rounded-xl border-2 text-left transition-all duration-300",
                "hover:scale-[1.02] hover:shadow-lg",
                isSelected
                  ? "border-primary bg-primary/10 shadow-glow"
                  : "border-border bg-card hover:border-primary/50"
              )}
            >
              {isSelected && (
                <div className="absolute top-3 right-3 w-6 h-6 rounded-full gradient-primary flex items-center justify-center shadow-neon">
                  <Check className="w-4 h-4 text-primary-foreground" />
                </div>
              )}

              <div className="flex items-start gap-3">
                <div
                  className={cn(
                    "w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br shadow-lg",
                    gradientColor
                  )}
                >
                  <PaymentIcon className="w-6 h-6 text-white" />
                </div>

                <div className="flex-1">
                  <p className="font-semibold text-lg">{payment.payment_name}</p>
                  <p className="text-sm text-muted-foreground">
                    {getPaymentTypeLabel(payment.payment_type, payment.payment_name)}
                  </p>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Payment Details - Show after selection */}
      {selectedInfo && (
        <div className="neon-card rounded-xl p-6 animate-fade-in">
          <div className="flex items-center gap-2 mb-4">
            <Icon className="w-5 h-5 text-primary" />
            <h4 className="font-semibold">
              {getPaymentDetailTitle(selectedInfo.payment_type, selectedInfo.payment_name)}
            </h4>
          </div>
          
          <div className="space-y-4">
            <div className="bg-muted/50 rounded-lg p-4">
              <p className="text-sm text-muted-foreground mb-1">
                {selectedInfo.payment_type === "bank_transfer" ? "Bank" : "E-Wallet"}
              </p>
              <p className="font-bold text-lg">{selectedInfo.payment_name}</p>
            </div>
            
            {selectedInfo.account_number && (
              <div className="bg-muted/50 rounded-lg p-4">
                <p className="text-sm text-muted-foreground mb-1">
                  {getAccountLabel(selectedInfo.payment_type)}
                </p>
                <p className="font-mono font-bold text-xl tracking-wider neon-text">
                  {selectedInfo.account_number}
                </p>
              </div>
            )}
            
            {selectedInfo.account_holder && (
              <div className="bg-muted/50 rounded-lg p-4">
                <p className="text-sm text-muted-foreground mb-1">Atas Nama</p>
                <p className="font-bold text-lg">{selectedInfo.account_holder}</p>
              </div>
            )}
          </div>
          
          <div className="mt-4 p-3 bg-primary/10 border border-primary/30 rounded-lg">
            <p className="text-sm text-primary">
              ⚠️ Pastikan detail penerima sesuai sebelum transfer
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
