import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Star, Plus, Send } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";

const reviewSchema = z.object({
  customer_name: z.string().trim().min(2, "Nama minimal 2 karakter").max(100, "Nama maksimal 100 karakter"),
  service_type: z.string().min(1, "Pilih jenis layanan"),
  rating: z.number().min(1).max(5),
  content: z.string().trim().min(10, "Review minimal 10 karakter").max(1000, "Review maksimal 1000 karakter")
});

const serviceTypes = [
  { value: "vocal_class", label: "Vocal Class" },
  { value: "studio_rental", label: "Studio Rental" },
  { value: "music_production", label: "Music Production" },
  { value: "recording", label: "Recording" },
  { value: "another_service", label: "Another Service" }
];

interface ReviewFormProps {
  onSuccess: () => void;
}

export function ReviewForm({ onSuccess }: ReviewFormProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [customerName, setCustomerName] = useState("");
  const [serviceType, setServiceType] = useState("");
  const [rating, setRating] = useState(5);
  const [content, setContent] = useState("");
  const [hoveredRating, setHoveredRating] = useState(0);

  const resetForm = () => {
    setCustomerName("");
    setServiceType("");
    setRating(5);
    setContent("");
    setHoveredRating(0);
  };

  const handleSubmit = async () => {
    const validation = reviewSchema.safeParse({
      customer_name: customerName,
      service_type: serviceType,
      rating,
      content
    });

    if (!validation.success) {
      toast.error(validation.error.errors[0].message);
      return;
    }

    setIsLoading(true);

    const { error } = await supabase
      .from("reviews")
      .insert({
        customer_name: customerName.trim(),
        service_type: serviceType,
        rating,
        content: content.trim(),
        is_published: true
      });

    if (error) {
      console.error("Error submitting review:", error);
      toast.error("Gagal mengirim review, silakan coba lagi");
      setIsLoading(false);
      return;
    }

    toast.success("Terima kasih! Review Anda berhasil dikirim 🎉");
    resetForm();
    setIsOpen(false);
    setIsLoading(false);
    onSuccess();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
      setIsOpen(open);
      if (!open) resetForm();
    }}>
      <DialogTrigger asChild>
        <Button variant="hero" className="btn-glow hover-glow">
          <Plus className="mr-2 h-4 w-4" />
          Tulis Review
        </Button>
      </DialogTrigger>
      <DialogContent className="neon-card max-w-md border-primary/30">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold neon-text">
            Berikan Review Anda
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-5 mt-4">
          {/* Name Input */}
          <div className="space-y-2">
            <Label className="text-foreground/90">Nama Anda</Label>
            <Input
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder="Masukkan nama Anda"
              className="bg-muted/50 border-primary/20 focus:border-primary"
              maxLength={100}
            />
          </div>

          {/* Service Type */}
          <div className="space-y-2">
            <Label className="text-foreground/90">Layanan yang Digunakan</Label>
            <Select value={serviceType} onValueChange={setServiceType}>
              <SelectTrigger className="bg-muted/50 border-primary/20 focus:border-primary">
                <SelectValue placeholder="Pilih layanan" />
              </SelectTrigger>
              <SelectContent>
                {serviceTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Star Rating */}
          <div className="space-y-2">
            <Label className="text-foreground/90">Rating</Label>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoveredRating(star)}
                  onMouseLeave={() => setHoveredRating(0)}
                  className="p-1 transition-transform hover:scale-110"
                >
                  <Star
                    className={`w-8 h-8 transition-all ${
                      star <= (hoveredRating || rating) 
                        ? "fill-yellow-400 text-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.5)]" 
                        : "text-muted-foreground/30"
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Review Content */}
          <div className="space-y-2">
            <Label className="text-foreground/90">Review Anda</Label>
            <Textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Ceritakan pengalaman Anda di Arkoji Studio..."
              rows={4}
              className="bg-muted/50 border-primary/20 focus:border-primary resize-none"
              maxLength={1000}
            />
            <p className="text-xs text-muted-foreground text-right">
              {content.length}/1000
            </p>
          </div>

          <Button 
            onClick={handleSubmit} 
            className="w-full btn-glow" 
            variant="hero"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary-foreground mr-2" />
                Mengirim...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Kirim Review
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
