import { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { Plus, Edit2, Trash2, Star, ArrowLeft, Eye, EyeOff, Upload, X, Image } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

interface Review {
  id: string;
  customer_name: string;
  service_type: string;
  rating: number;
  content: string;
  image_url: string | null;
  is_published: boolean;
  created_at: string;
}

const serviceTypes = [
  { value: "vocal_class", label: "Vocal Class" },
  { value: "studio_rental", label: "Studio Rental" },
  { value: "another_service", label: "Another Service" }
];

export default function AdminReviews() {
  const navigate = useNavigate();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingReview, setEditingReview] = useState<Review | null>(null);
  
  // Form state
  const [customerName, setCustomerName] = useState("");
  const [serviceType, setServiceType] = useState("");
  const [rating, setRating] = useState(5);
  const [content, setContent] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isPublished, setIsPublished] = useState(true);

  useEffect(() => {
    checkAdminAndLoad();
  }, []);

  const checkAdminAndLoad = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error("Silakan login terlebih dahulu");
        navigate("/auth");
        return;
      }

      const { data: roleData, error: roleError } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .eq("role", "admin")
        .maybeSingle();

      if (roleError || !roleData) {
        toast.error("Anda tidak memiliki akses admin");
        navigate("/");
        return;
      }

      setIsAdmin(true);
      await loadReviews();
    } catch (error) {
      console.error("Error:", error);
      navigate("/");
    } finally {
      setIsLoading(false);
    }
  };

  const loadReviews = async () => {
    const { data, error } = await supabase
      .from("reviews")
      .select("*")
      .order("created_at", { ascending: false });

    if (!error && data) {
      setReviews(data);
    }
  };

  const resetForm = () => {
    setCustomerName("");
    setServiceType("");
    setRating(5);
    setContent("");
    setImageUrl("");
    setImageFile(null);
    setImagePreview(null);
    setIsPublished(true);
    setEditingReview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error("Ukuran file maksimal 5MB");
        return;
      }
      if (!file.type.startsWith("image/")) {
        toast.error("Hanya file gambar yang diperbolehkan");
        return;
      }
      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
      setImageUrl(""); // Clear URL if uploading file
    }
  };

  const removeImage = () => {
    setImageFile(null);
    setImagePreview(null);
    setImageUrl("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const uploadImage = async (file: File): Promise<string | null> => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
    const filePath = `reviews/${fileName}`;

    const { error } = await supabase.storage
      .from('review-images')
      .upload(filePath, file);

    if (error) {
      console.error("Upload error:", error);
      return null;
    }

    const { data: { publicUrl } } = supabase.storage
      .from('review-images')
      .getPublicUrl(filePath);

    return publicUrl;
  };

  const openEditDialog = (review: Review) => {
    setEditingReview(review);
    setCustomerName(review.customer_name);
    setServiceType(review.service_type);
    setRating(review.rating);
    setContent(review.content);
    setImageUrl(review.image_url || "");
    setImageFile(null);
    setImagePreview(null);
    setIsPublished(review.is_published);
    setIsDialogOpen(true);
  };

  const handleSubmit = async () => {
    if (!customerName || !serviceType || !content) {
      toast.error("Mohon isi semua field yang diperlukan");
      return;
    }

    setIsUploading(true);
    let finalImageUrl = imageUrl;

    // Upload image if file is selected
    if (imageFile) {
      const uploadedUrl = await uploadImage(imageFile);
      if (!uploadedUrl) {
        toast.error("Gagal mengupload foto");
        setIsUploading(false);
        return;
      }
      finalImageUrl = uploadedUrl;
    }

    const reviewData = {
      customer_name: customerName,
      service_type: serviceType,
      rating,
      content,
      image_url: finalImageUrl || null,
      is_published: isPublished
    };

    if (editingReview) {
      const { error } = await supabase
        .from("reviews")
        .update(reviewData)
        .eq("id", editingReview.id);

      if (error) {
        toast.error("Gagal mengupdate review");
        setIsUploading(false);
        return;
      }
      toast.success("Review berhasil diupdate");
    } else {
      const { error } = await supabase
        .from("reviews")
        .insert(reviewData);

      if (error) {
        toast.error("Gagal menambah review");
        setIsUploading(false);
        return;
      }
      toast.success("Review berhasil ditambah");
    }

    setIsUploading(false);
    setIsDialogOpen(false);
    resetForm();
    loadReviews();
  };

  const deleteReview = async (id: string) => {
    if (!confirm("Yakin ingin menghapus review ini?")) return;

    const { error } = await supabase
      .from("reviews")
      .delete()
      .eq("id", id);

    if (error) {
      toast.error("Gagal menghapus review");
      return;
    }

    toast.success("Review berhasil dihapus");
    loadReviews();
  };

  const togglePublished = async (review: Review) => {
    const { error } = await supabase
      .from("reviews")
      .update({ is_published: !review.is_published })
      .eq("id", review.id);

    if (error) {
      toast.error("Gagal mengupdate status");
      return;
    }

    toast.success(review.is_published ? "Review disembunyikan" : "Review dipublikasikan");
    loadReviews();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <Button variant="ghost" onClick={() => navigate("/admin")} className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Kembali ke Dashboard
        </Button>

        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold gradient-primary bg-clip-text text-transparent">
              Kelola Reviews
            </h1>
            <p className="text-muted-foreground mt-2">Tambah, edit, atau hapus testimonial pelanggan</p>
          </div>

          <Dialog open={isDialogOpen} onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button variant="hero">
                <Plus className="mr-2 h-4 w-4" />
                Tambah Review
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>
                  {editingReview ? "Edit Review" : "Tambah Review Baru"}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>Nama Customer *</Label>
                  <Input
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Nama pelanggan"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Jenis Layanan *</Label>
                  <Select value={serviceType} onValueChange={setServiceType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih layanan" />
                    </SelectTrigger>
                    <SelectContent>
                      {serviceTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Rating *</Label>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setRating(star)}
                        className="p-1"
                      >
                        <Star
                          className={`w-6 h-6 ${star <= rating ? "fill-primary text-primary" : "text-muted-foreground"}`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Isi Review *</Label>
                  <Textarea
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder="Tulis review pelanggan..."
                    rows={4}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Foto Customer (Optional)</Label>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept="image/*"
                    className="hidden"
                  />
                  
                  {imagePreview || imageUrl ? (
                    <div className="relative inline-block">
                      <img
                        src={imagePreview || imageUrl}
                        alt="Preview"
                        className="w-20 h-20 rounded-full object-cover border-2 border-primary"
                      />
                      <button
                        type="button"
                        onClick={removeImage}
                        className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground rounded-full p-1"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ) : (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full"
                    >
                      <Upload className="mr-2 h-4 w-4" />
                      Upload Foto
                    </Button>
                  )}
                  <p className="text-xs text-muted-foreground">Max 5MB, format JPG/PNG</p>
                </div>

                <div className="flex items-center justify-between">
                  <Label>Publikasikan</Label>
                  <Switch checked={isPublished} onCheckedChange={setIsPublished} />
                </div>

                <Button onClick={handleSubmit} className="w-full" variant="hero" disabled={isUploading}>
                  {isUploading ? "Mengupload..." : editingReview ? "Update Review" : "Simpan Review"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {reviews.length === 0 ? (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground">Belum ada review</p>
          </Card>
        ) : (
          <div className="grid gap-4">
            {reviews.map((review) => (
              <Card key={review.id} className="p-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold">{review.customer_name}</h3>
                      <span className="text-sm text-muted-foreground">
                        {serviceTypes.find(s => s.value === review.service_type)?.label}
                      </span>
                      {!review.is_published && (
                        <span className="text-xs bg-muted px-2 py-1 rounded">Draft</span>
                      )}
                    </div>
                    <div className="flex gap-0.5 mb-2">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${i < review.rating ? "fill-primary text-primary" : "text-muted-foreground"}`}
                        />
                      ))}
                    </div>
                    <p className="text-muted-foreground">{review.content}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => togglePublished(review)}
                    >
                      {review.is_published ? (
                        <Eye className="h-4 w-4" />
                      ) : (
                        <EyeOff className="h-4 w-4" />
                      )}
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => openEditDialog(review)}
                    >
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteReview(review.id)}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}