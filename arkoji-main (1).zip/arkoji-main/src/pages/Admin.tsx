import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { format } from "date-fns";
import { id } from "date-fns/locale";
import { LogOut, Calendar, Clock, User, Phone, Mail, FileText, CheckCircle, XCircle, Star, DollarSign, ChevronLeft, ChevronRight, CreditCard, Plus, Trash2, Image } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const BOOKINGS_PER_PAGE = 10;

interface Booking {
  id: string;
  booking_type: string;
  booking_date: string;
  start_time: string;
  end_time: string;
  customer_name: string;
  customer_phone: string;
  customer_email: string | null;
  notes: string | null;
  status: string;
  created_at: string;
  payment_method: string | null;
  payment_status: string | null;
  payment_amount: number | null;
  payment_proof_url: string | null;
  paid_at: string | null;
}

interface PaymentSetting {
  id: string;
  payment_type: string;
  payment_name: string;
  account_number: string | null;
  account_holder: string | null;
  qris_image_url: string | null;
  is_active: boolean;
}

const bookingTypeLabels: Record<string, string> = {
  vocal_class: "Vocal Class",
  studio_rental: "Studio Rental",
  music_production: "Music & Jingle Production",
  another_service: "Another Service",
  recording: "Recording"
};

export default function Admin() {
  const navigate = useNavigate();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [currentPage, setCurrentPage] = useState<Record<string, number>>({
    all: 1,
    pending: 1,
    confirmed: 1,
    cancelled: 1,
  });
  
  // Payment settings state
  const [paymentSettings, setPaymentSettings] = useState<PaymentSetting[]>([]);
  const [isAddingPayment, setIsAddingPayment] = useState(false);
  const [newPayment, setNewPayment] = useState({
    payment_type: "bank_transfer",
    payment_name: "",
    account_number: "",
    account_holder: "",
    qris_image_url: ""
  });
  const [qrisFile, setQrisFile] = useState<File | null>(null);
  const [isUploadingQris, setIsUploadingQris] = useState(false);

  useEffect(() => {
    checkAdminAndLoadBookings();
  }, []);

  const checkAdminAndLoadBookings = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        toast.error("Silakan login terlebih dahulu");
        navigate("/auth");
        return;
      }

      // Check if user is admin
      const { data: roleData, error: roleError } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .eq("role", "admin")
        .maybeSingle();

      if (roleError || !roleData) {
        toast.error("Anda tidak memiliki akses admin");
        navigate("/");
        return;
      }

      setIsAdmin(true);
      await Promise.all([loadBookings(), loadPaymentSettings()]);
    } catch (error) {
      console.error("Error:", error);
      toast.error("Terjadi kesalahan");
      navigate("/");
    } finally {
      setIsLoading(false);
    }
  };

  const loadBookings = async () => {
    const { data, error } = await supabase
      .from("bookings")
      .select("*")
      .order("booking_date", { ascending: false })
      .order("start_time", { ascending: true });

    if (error) {
      toast.error("Gagal memuat booking");
      return;
    }

    setBookings(data || []);
  };

  const loadPaymentSettings = async () => {
    const { data, error } = await supabase
      .from("payment_settings")
      .select("*")
      .order("created_at", { ascending: true });

    if (error) {
      console.error("Error loading payment settings:", error);
      return;
    }

    setPaymentSettings(data || []);
  };

  const updateBookingStatus = async (bookingId: string, newStatus: "pending" | "confirmed" | "cancelled") => {
    const booking = bookings.find(b => b.id === bookingId);
    if (!booking) {
      toast.error("Booking tidak ditemukan");
      return;
    }

    const { error } = await supabase
      .from("bookings")
      .update({ status: newStatus })
      .eq("id", bookingId);

    if (error) {
      toast.error("Gagal update status");
      return;
    }

    // Auto-add income to accounting when booking is confirmed
    if (newStatus === "confirmed" && booking.payment_amount) {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        const bookingLabel = bookingTypeLabels[booking.booking_type] || booking.booking_type;
        
        await supabase
          .from("accounting_entries")
          .insert({
            entry_date: booking.booking_date,
            entry_type: "income",
            category: bookingLabel,
            description: `Booking ${bookingLabel} - ${booking.customer_name}`,
            amount: booking.payment_amount,
            notes: `Booking ID: ${booking.id}`,
            created_by: user?.id || null
          });
        
        toast.success("Pemasukan ditambahkan ke pembukuan");
      } catch (accountingError) {
        console.error("Failed to add accounting entry:", accountingError);
      }
    }

    if ((newStatus === "confirmed" || newStatus === "cancelled") && booking.customer_email) {
      try {
        await supabase.functions.invoke("send-booking-notification", {
          body: {
            customerName: booking.customer_name,
            customerEmail: booking.customer_email,
            customerPhone: booking.customer_phone,
            bookingType: booking.booking_type,
            bookingDate: booking.booking_date,
            startTime: booking.start_time,
            endTime: booking.end_time,
            status: newStatus,
          },
        });
      } catch (emailError) {
        console.error("Failed to send email:", emailError);
      }
    }

    toast.success("Status berhasil diupdate");
    loadBookings();
  };

  const handleAddPaymentSetting = async () => {
    if (!newPayment.payment_name) {
      toast.error("Nama pembayaran harus diisi");
      return;
    }

    setIsUploadingQris(true);
    let qrisUrl = newPayment.qris_image_url;

    // Upload QRIS image if provided
    if (qrisFile) {
      const fileExt = qrisFile.name.split('.').pop();
      const fileName = `qris-${Date.now()}.${fileExt}`;
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from("payment-proofs")
        .upload(fileName, qrisFile);

      if (uploadError) {
        console.error("Upload error:", uploadError);
        toast.error("Gagal upload gambar QRIS");
        setIsUploadingQris(false);
        return;
      }

      const { data: urlData } = supabase.storage
        .from("payment-proofs")
        .getPublicUrl(fileName);

      qrisUrl = urlData.publicUrl;
    }

    const { error } = await supabase
      .from("payment_settings")
      .insert({
        payment_type: newPayment.payment_type,
        payment_name: newPayment.payment_name,
        account_number: newPayment.account_number || null,
        account_holder: newPayment.account_holder || null,
        qris_image_url: qrisUrl || null,
        is_active: true
      });

    if (error) {
      console.error("Error adding payment:", error);
      toast.error("Gagal menambah metode pembayaran");
      setIsUploadingQris(false);
      return;
    }

    toast.success("Metode pembayaran berhasil ditambahkan");
    setNewPayment({
      payment_type: "bank_transfer",
      payment_name: "",
      account_number: "",
      account_holder: "",
      qris_image_url: ""
    });
    setQrisFile(null);
    setIsAddingPayment(false);
    setIsUploadingQris(false);
    loadPaymentSettings();
  };

  const handleDeletePaymentSetting = async (id: string) => {
    const { error } = await supabase
      .from("payment_settings")
      .delete()
      .eq("id", id);

    if (error) {
      toast.error("Gagal menghapus metode pembayaran");
      return;
    }

    toast.success("Metode pembayaran dihapus");
    loadPaymentSettings();
  };

  const togglePaymentActive = async (id: string, isActive: boolean) => {
    const { error } = await supabase
      .from("payment_settings")
      .update({ is_active: !isActive })
      .eq("id", id);

    if (error) {
      toast.error("Gagal update status");
      return;
    }

    loadPaymentSettings();
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast.success("Logout berhasil");
    navigate("/");
  };

  const filterBookings = (status: string) => {
    if (status === "all") return bookings;
    return bookings.filter(b => b.status === status);
  };

  const getPaginatedBookings = (status: string) => {
    const filtered = filterBookings(status);
    const page = currentPage[status] || 1;
    const start = (page - 1) * BOOKINGS_PER_PAGE;
    const end = start + BOOKINGS_PER_PAGE;
    return filtered.slice(start, end);
  };

  const getTotalPages = (status: string) => {
    return Math.ceil(filterBookings(status).length / BOOKINGS_PER_PAGE);
  };

  const handlePageChange = (status: string, page: number) => {
    setCurrentPage(prev => ({ ...prev, [status]: page }));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-4xl font-bold gradient-primary bg-clip-text text-transparent">
              Admin Dashboard
            </h1>
            <p className="text-muted-foreground mt-2">Kelola semua booking studio</p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button variant="outline" onClick={() => navigate("/admin/reviews")}>
              <Star className="mr-2 h-4 w-4" />
              Kelola Reviews
            </Button>
            <Button variant="outline" onClick={() => navigate("/admin/accounting")}>
              <DollarSign className="mr-2 h-4 w-4" />
              Pembukuan
            </Button>
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>

        <Tabs defaultValue="bookings" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 lg:w-auto lg:inline-flex">
            <TabsTrigger value="bookings">Booking</TabsTrigger>
            <TabsTrigger value="payments">Metode Pembayaran</TabsTrigger>
          </TabsList>

          <TabsContent value="bookings">
            <Tabs defaultValue="all" className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="all">Semua ({bookings.length})</TabsTrigger>
                <TabsTrigger value="pending">Pending ({filterBookings("pending").length})</TabsTrigger>
                <TabsTrigger value="confirmed">Confirmed ({filterBookings("confirmed").length})</TabsTrigger>
                <TabsTrigger value="cancelled">Cancelled ({filterBookings("cancelled").length})</TabsTrigger>
              </TabsList>

              {["all", "pending", "confirmed", "cancelled"].map((status) => {
                const paginatedBookings = getPaginatedBookings(status);
                const totalPages = getTotalPages(status);
                const page = currentPage[status] || 1;

                return (
                  <TabsContent key={status} value={status} className="space-y-4">
                    {filterBookings(status).length === 0 ? (
                      <Card className="p-12 text-center">
                        <p className="text-muted-foreground">Tidak ada booking</p>
                      </Card>
                    ) : (
                      <>
                        {paginatedBookings.map((booking) => (
                          <Card key={booking.id} className="p-6 hover:shadow-elevated transition-shadow">
                            <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                              <div className="space-y-3 flex-1">
                                <div className="flex items-center gap-3 flex-wrap">
                                  <h3 className="text-xl font-semibold">
                                    {bookingTypeLabels[booking.booking_type] || booking.booking_type}
                                  </h3>
                                  <Badge
                                    variant={
                                      booking.status === "confirmed"
                                        ? "default"
                                        : booking.status === "cancelled"
                                        ? "destructive"
                                        : "secondary"
                                    }
                                  >
                                    {booking.status}
                                  </Badge>
                                  {booking.payment_status === "paid" && (
                                    <Badge variant="outline" className="bg-green-500/10 text-green-600 border-green-500/30">
                                      Sudah Bayar
                                    </Badge>
                                  )}
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                                  <div className="flex items-center gap-2">
                                    <Calendar className="h-4 w-4 text-primary" />
                                    <span>{format(new Date(booking.booking_date), "PPP", { locale: id })}</span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <Clock className="h-4 w-4 text-primary" />
                                    <span>{booking.start_time} - {booking.end_time}</span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <User className="h-4 w-4 text-primary" />
                                    <span>{booking.customer_name}</span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <Phone className="h-4 w-4 text-primary" />
                                    <span>{booking.customer_phone}</span>
                                  </div>
                                  {booking.customer_email && (
                                    <div className="flex items-center gap-2 col-span-full">
                                      <Mail className="h-4 w-4 text-primary" />
                                      <span>{booking.customer_email}</span>
                                    </div>
                                  )}
                                  {booking.payment_amount && (
                                    <div className="flex items-center gap-2">
                                      <CreditCard className="h-4 w-4 text-primary" />
                                      <span>Rp {booking.payment_amount.toLocaleString("id-ID")}</span>
                                    </div>
                                  )}
                                  {booking.notes && (
                                    <div className="flex items-start gap-2 col-span-full">
                                      <FileText className="h-4 w-4 text-primary mt-0.5" />
                                      <span className="text-muted-foreground">{booking.notes}</span>
                                    </div>
                                  )}
                                </div>

                                {/* Payment Proof */}
                                {booking.payment_proof_url && (
                                  <Dialog>
                                    <DialogTrigger asChild>
                                      <Button variant="outline" size="sm">
                                        <Image className="mr-2 h-4 w-4" />
                                        Lihat Bukti Bayar
                                      </Button>
                                    </DialogTrigger>
                                    <DialogContent className="max-w-lg">
                                      <DialogHeader>
                                        <DialogTitle>Bukti Pembayaran</DialogTitle>
                                      </DialogHeader>
                                      <img
                                        src={booking.payment_proof_url}
                                        alt="Bukti pembayaran"
                                        className="w-full rounded-lg"
                                      />
                                    </DialogContent>
                                  </Dialog>
                                )}
                              </div>

                              {booking.status === "pending" && (
                                <div className="flex gap-2">
                                  <Button
                                    variant="default"
                                    size="sm"
                                    onClick={() => updateBookingStatus(booking.id, "confirmed")}
                                  >
                                    <CheckCircle className="mr-2 h-4 w-4" />
                                    Confirm
                                  </Button>
                                  <Button
                                    variant="destructive"
                                    size="sm"
                                    onClick={() => updateBookingStatus(booking.id, "cancelled")}
                                  >
                                    <XCircle className="mr-2 h-4 w-4" />
                                    Cancel
                                  </Button>
                                </div>
                              )}
                            </div>
                          </Card>
                        ))}

                        {/* Pagination */}
                        {totalPages > 1 && (
                          <div className="flex items-center justify-center gap-2 pt-4">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handlePageChange(status, page - 1)}
                              disabled={page === 1}
                            >
                              <ChevronLeft className="h-4 w-4" />
                              Prev
                            </Button>
                            <div className="flex items-center gap-1">
                              {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => (
                                <Button
                                  key={pageNum}
                                  variant={pageNum === page ? "default" : "outline"}
                                  size="sm"
                                  className="w-8 h-8 p-0"
                                  onClick={() => handlePageChange(status, pageNum)}
                                >
                                  {pageNum}
                                </Button>
                              ))}
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handlePageChange(status, page + 1)}
                              disabled={page === totalPages}
                            >
                              Next
                              <ChevronRight className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </>
                    )}
                  </TabsContent>
                );
              })}
            </Tabs>
          </TabsContent>

          <TabsContent value="payments" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold">Metode Pembayaran</h2>
              <Dialog open={isAddingPayment} onOpenChange={setIsAddingPayment}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Tambah Metode
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Tambah Metode Pembayaran</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label>Tipe Pembayaran</Label>
                      <select
                        className="w-full p-2 rounded-lg border border-border bg-background"
                        value={newPayment.payment_type}
                        onChange={(e) => setNewPayment(prev => ({ ...prev, payment_type: e.target.value }))}
                      >
                        <option value="bank_transfer">Transfer Bank</option>
                        <option value="qris">QRIS</option>
                        <option value="ewallet">E-Wallet</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <Label>Nama Pembayaran *</Label>
                      <Input
                        placeholder="e.g. BCA, Mandiri, DANA, GoPay"
                        value={newPayment.payment_name}
                        onChange={(e) => setNewPayment(prev => ({ ...prev, payment_name: e.target.value }))}
                      />
                    </div>
                    {newPayment.payment_type !== "qris" && (
                      <>
                        <div className="space-y-2">
                          <Label>Nomor Rekening/Akun</Label>
                          <Input
                            placeholder="1234567890"
                            value={newPayment.account_number}
                            onChange={(e) => setNewPayment(prev => ({ ...prev, account_number: e.target.value }))}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Nama Pemilik</Label>
                          <Input
                            placeholder="Nama pada rekening"
                            value={newPayment.account_holder}
                            onChange={(e) => setNewPayment(prev => ({ ...prev, account_holder: e.target.value }))}
                          />
                        </div>
                      </>
                    )}
                    {newPayment.payment_type === "qris" && (
                      <div className="space-y-2">
                        <Label>Upload Gambar QRIS</Label>
                        <Input
                          type="file"
                          accept="image/*"
                          onChange={(e) => setQrisFile(e.target.files?.[0] || null)}
                        />
                      </div>
                    )}
                    <Button
                      className="w-full"
                      onClick={handleAddPaymentSetting}
                      disabled={isUploadingQris}
                    >
                      {isUploadingQris ? "Menyimpan..." : "Simpan"}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {paymentSettings.length === 0 ? (
              <Card className="p-12 text-center">
                <CreditCard className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">Belum ada metode pembayaran</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Tambahkan metode pembayaran agar pelanggan dapat melakukan pembayaran
                </p>
              </Card>
            ) : (
              <div className="grid gap-4">
                {paymentSettings.map((payment) => (
                  <Card key={payment.id} className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        {payment.qris_image_url && (
                          <img
                            src={payment.qris_image_url}
                            alt="QRIS"
                            className="w-16 h-16 object-cover rounded-lg"
                          />
                        )}
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold">{payment.payment_name}</h3>
                            <Badge variant={payment.is_active ? "default" : "secondary"}>
                              {payment.is_active ? "Aktif" : "Nonaktif"}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground capitalize">
                            {payment.payment_type.replace("_", " ")}
                          </p>
                          {payment.account_number && (
                            <p className="text-sm">
                              {payment.account_number} - {payment.account_holder}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => togglePaymentActive(payment.id, payment.is_active)}
                        >
                          {payment.is_active ? "Nonaktifkan" : "Aktifkan"}
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDeletePaymentSetting(payment.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
