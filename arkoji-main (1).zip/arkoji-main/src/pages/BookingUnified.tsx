import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, getDay } from "date-fns";
import { id as localeId } from "date-fns/locale";
import { 
  CalendarIcon, Clock, Music, Headphones, ChevronLeft, ChevronRight, 
  Upload, CheckCircle2, ArrowLeft, Sparkles, Phone, Mail, User
} from "lucide-react";
import { cn } from "@/lib/utils";
import { BookingProgress } from "@/components/booking/BookingProgress";
import { BookingSummaryCard } from "@/components/booking/BookingSummaryCard";
import { PaymentMethodSelector } from "@/components/booking/PaymentMethodSelector";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Constants
const PRICE_PER_HOUR = 150000;
const PRICE_PER_SHIFT = 800000;

const timeSlots = [
  "10:00", "11:00", "12:00", "13:00", "14:00", 
  "15:00", "16:00", "17:00", "18:00", "19:00", "20:00", "21:00", "22:00"
];

const shiftOptions = [
  { id: "pagi", label: "Shift Pagi", startTime: "09:00", endTime: "15:00", description: "09:00 - 15:00 (6 jam)" },
  { id: "sore", label: "Shift Sore", startTime: "16:00", endTime: "22:00", description: "16:00 - 22:00 (6 jam)" },
];

type ServiceType = "studio_rental" | "recording";

interface BookingSlot {
  booking_date: string;
  start_time: string;
  end_time: string;
  status: string;
  booking_type: string;
}

interface PaymentSetting {
  id: string;
  payment_type: string;
  payment_name: string;
  account_number: string | null;
  account_holder: string | null;
}

type BookingStep = "service" | "form" | "payment" | "success";

export default function BookingUnified() {
  const navigate = useNavigate();
  const [step, setStep] = useState<BookingStep>("service");
  const [serviceType, setServiceType] = useState<ServiceType | null>(null);
  const [date, setDate] = useState<Date>();
  const [startTime, setStartTime] = useState<string>("");
  const [endTime, setEndTime] = useState<string>("");
  const [selectedShift, setSelectedShift] = useState<string>("");
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [notes, setNotes] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [bookedSlots, setBookedSlots] = useState<BookingSlot[]>([]);
  const [calendarMonth, setCalendarMonth] = useState(new Date());
  
  // Payment state
  const [paymentSettings, setPaymentSettings] = useState<PaymentSetting[]>([]);
  const [selectedPayment, setSelectedPayment] = useState<string>("");
  const [paymentProof, setPaymentProof] = useState<File | null>(null);
  const [paymentProofPreview, setPaymentProofPreview] = useState<string>("");
  const [isUploading, setIsUploading] = useState(false);

  useEffect(() => {
    loadBookedSlots();
    loadPaymentSettings();
  }, [calendarMonth, serviceType]);

  const loadBookedSlots = async () => {
    const start = startOfMonth(calendarMonth);
    const end = endOfMonth(calendarMonth);
    
    const { data, error } = await supabase
      .from("bookings")
      .select("booking_date, start_time, end_time, status, booking_type")
      .gte("booking_date", format(start, "yyyy-MM-dd"))
      .lte("booking_date", format(end, "yyyy-MM-dd"))
      .in("status", ["pending", "confirmed"]);

    if (!error && data) {
      setBookedSlots(data);
    }
  };

  const loadPaymentSettings = async () => {
    const { data, error } = await supabase
      .from("payment_settings_public")
      .select("*");

    if (!error && data) {
      setPaymentSettings(data);
      if (data.length > 0) {
        setSelectedPayment(data[0].id);
      }
    }
  };

  // For studio rental - check if slot is booked
  const getSlotStatus = (slotDate: Date, time: string) => {
    const dateStr = format(slotDate, "yyyy-MM-dd");
    const booked = bookedSlots.filter(
      slot => slot.booking_date === dateStr && 
              slot.booking_type === "studio_rental" &&
              slot.start_time <= time && slot.end_time > time
    );
    return booked.length > 0 ? "booked" : "available";
  };

  // For recording - check if shift is booked
  const isShiftBooked = (slotDate: Date, shiftId: string) => {
    const dateStr = format(slotDate, "yyyy-MM-dd");
    const shift = shiftOptions.find(s => s.id === shiftId);
    if (!shift) return false;
    
    return bookedSlots.some(
      slot => slot.booking_date === dateStr && 
              slot.booking_type === "recording" &&
              slot.start_time === shift.startTime && 
              slot.end_time === shift.endTime
    );
  };

  const getDayStatus = (day: Date) => {
    const dateStr = format(day, "yyyy-MM-dd");
    
    if (serviceType === "studio_rental") {
      const dayBookings = bookedSlots.filter(
        slot => slot.booking_date === dateStr && slot.booking_type === "studio_rental"
      );
      if (dayBookings.length === 0) return "available";
      if (dayBookings.length >= timeSlots.length - 1) return "full";
      return "partial";
    } else {
      const dayBookings = bookedSlots.filter(
        slot => slot.booking_date === dateStr && slot.booking_type === "recording"
      );
      if (dayBookings.length === 0) return "available";
      if (dayBookings.length >= shiftOptions.length) return "full";
      return "partial";
    }
  };

  const calculateHours = () => {
    if (!startTime || !endTime) return 0;
    const startHour = parseInt(startTime.split(":")[0]);
    const endHour = parseInt(endTime.split(":")[0]);
    return Math.max(0, endHour - startHour);
  };

  const calculateTotal = () => {
    if (serviceType === "recording") {
      return PRICE_PER_SHIFT;
    }
    return calculateHours() * PRICE_PER_HOUR;
  };

  const getAvailableEndTimes = () => {
    if (!startTime || !date) return [];
    const startIndex = timeSlots.indexOf(startTime);
    if (startIndex === -1) return [];
    
    const dateStr = format(date, "yyyy-MM-dd");
    const availableEndTimes: string[] = [];
    
    for (let i = startIndex + 1; i < timeSlots.length; i++) {
      const time = timeSlots[i];
      const isBlocked = bookedSlots.some(slot => 
        slot.booking_date === dateStr && 
        slot.booking_type === "studio_rental" &&
        slot.start_time < time && 
        slot.start_time >= startTime
      );
      if (isBlocked) break;
      availableEndTimes.push(time);
    }
    
    return availableEndTimes;
  };

  const handleStartTimeChange = (time: string) => {
    setStartTime(time);
    setEndTime("");
  };

  const handleShiftSelect = (shiftId: string) => {
    if (date && isShiftBooked(date, shiftId)) {
      toast.error("Shift ini sudah dibooking");
      return;
    }
    setSelectedShift(shiftId);
    const shift = shiftOptions.find(s => s.id === shiftId);
    if (shift) {
      setStartTime(shift.startTime);
      setEndTime(shift.endTime);
    }
  };

  const handleSelectService = (type: ServiceType) => {
    setServiceType(type);
    setStep("form");
    // Reset form when switching
    setDate(undefined);
    setStartTime("");
    setEndTime("");
    setSelectedShift("");
  };

  const handleProceedToPayment = (e: React.FormEvent) => {
    e.preventDefault();

    if (!date || !customerName || !customerPhone) {
      toast.error("Mohon isi semua field yang diperlukan");
      return;
    }

    if (serviceType === "studio_rental" && (!startTime || !endTime || calculateHours() < 1)) {
      toast.error("Minimal booking 1 jam");
      return;
    }

    if (serviceType === "recording" && !selectedShift) {
      toast.error("Mohon pilih shift");
      return;
    }

    setStep("payment");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handlePaymentProofChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error("Ukuran file maksimal 5MB");
        return;
      }
      setPaymentProof(file);
      setPaymentProofPreview(URL.createObjectURL(file));
    }
  };

  const handleSubmitBooking = async () => {
    if (!paymentProof) {
      toast.error("Mohon upload bukti pembayaran");
      return;
    }

    if (!selectedPayment) {
      toast.error("Mohon pilih metode pembayaran");
      return;
    }

    setIsSubmitting(true);
    setIsUploading(true);

    try {
      const fileExt = paymentProof.name.split('.').pop();
      const fileName = `proofs/${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from("payment-proofs")
        .upload(fileName, paymentProof);

      if (uploadError) {
        console.error("Upload error:", uploadError);
        throw new Error("Gagal mengupload bukti pembayaran");
      }

      const { data: urlData } = supabase.storage
        .from("payment-proofs")
        .getPublicUrl(fileName);

      setIsUploading(false);

      const { data, error } = await supabase.functions.invoke("create-booking", {
        body: {
          customer_name: customerName,
          customer_phone: customerPhone,
          customer_email: customerEmail || null,
          booking_type: serviceType,
          booking_date: format(date!, "yyyy-MM-dd"),
          start_time: startTime,
          end_time: endTime,
          notes: notes || null,
          payment_method: selectedPayment,
          payment_amount: calculateTotal(),
          payment_proof_url: urlData.publicUrl
        }
      });

      if (error) throw error;
      
      if (data?.error) {
        toast.error(data.error);
        setIsSubmitting(false);
        return;
      }

      setStep("success");
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (error: any) {
      console.error("Booking error:", error);
      toast.error(error.message || "Gagal membuat booking. Silakan coba lagi.");
    } finally {
      setIsSubmitting(false);
      setIsUploading(false);
    }
  };

  const calendarDays = eachDayOfInterval({
    start: startOfMonth(calendarMonth),
    end: endOfMonth(calendarMonth)
  });

  const firstDayOfMonth = getDay(startOfMonth(calendarMonth));

  // Service Selection Step
  if (step === "service") {
    return (
      <div className="min-h-screen py-12 px-4">
        <div className="max-w-2xl mx-auto">
          <Button
            variant="ghost"
            onClick={() => navigate("/")}
            className="mb-6 hover-lift"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Kembali
          </Button>

          <h1 className="text-3xl font-bold text-center mb-2 gradient-primary bg-clip-text text-transparent">
            Pilih Layanan
          </h1>
          <p className="text-muted-foreground text-center mb-8">
            Pilih layanan yang ingin Anda booking
          </p>

          <div className="grid gap-6">
            {/* Studio Rental Option */}
            <Card 
              className={cn(
                "glass-card p-6 cursor-pointer transition-all duration-300 hover:shadow-elevated",
                "border-2 hover:border-primary/50"
              )}
              onClick={() => handleSelectService("studio_rental")}
            >
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center shadow-glow">
                  <Music className="w-8 h-8 text-primary-foreground" />
                </div>
                <div className="flex-1">
                  <h2 className="text-xl font-bold gradient-primary bg-clip-text text-transparent">
                    Studio Rental
                  </h2>
                  <p className="text-muted-foreground text-sm mt-1">
                    Sewa studio per jam untuk latihan atau rekaman ringan
                  </p>
                  <p className="text-primary font-semibold text-lg mt-2">
                    Rp {PRICE_PER_HOUR.toLocaleString("id-ID")} <span className="text-sm text-muted-foreground font-normal">/ jam</span>
                  </p>
                </div>
                <ChevronRight className="w-6 h-6 text-muted-foreground" />
              </div>
            </Card>

            {/* Recording Option */}
            <Card 
              className={cn(
                "glass-card p-6 cursor-pointer transition-all duration-300 hover:shadow-elevated",
                "border-2 hover:border-primary/50"
              )}
              onClick={() => handleSelectService("recording")}
            >
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center shadow-glow">
                  <Headphones className="w-8 h-8 text-primary-foreground" />
                </div>
                <div className="flex-1">
                  <h2 className="text-xl font-bold gradient-primary bg-clip-text text-transparent">
                    Recording
                  </h2>
                  <p className="text-muted-foreground text-sm mt-1">
                    Sesi recording profesional dengan pilihan shift
                  </p>
                  <p className="text-primary font-semibold text-lg mt-2">
                    Rp {PRICE_PER_SHIFT.toLocaleString("id-ID")} <span className="text-sm text-muted-foreground font-normal">/ shift (6 jam)</span>
                  </p>
                  <div className="flex gap-2 mt-2">
                    <span className="text-xs bg-muted px-2 py-1 rounded-full">Pagi: 09:00-15:00</span>
                    <span className="text-xs bg-muted px-2 py-1 rounded-full">Sore: 16:00-22:00</span>
                  </div>
                </div>
                <ChevronRight className="w-6 h-6 text-muted-foreground" />
              </div>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  // Success Step
  if (step === "success") {
    return (
      <div className="min-h-screen py-12 px-4">
        <div className="max-w-lg mx-auto">
          <BookingProgress currentStep="success" />
          
          <Card className="glass-card p-8 text-center animate-scale-in">
            <div className="relative w-24 h-24 mx-auto mb-6">
              <div className="absolute inset-0 gradient-primary rounded-full animate-glow-pulse" />
              <div className="relative w-full h-full rounded-full gradient-primary flex items-center justify-center">
                <CheckCircle2 className="w-12 h-12 text-primary-foreground" />
              </div>
            </div>

            <h1 className="text-3xl font-bold mb-2 gradient-primary bg-clip-text text-transparent">
              Booking Berhasil! 🎉
            </h1>
            <p className="text-muted-foreground mb-8">
              Terima kasih! Booking Anda sedang diproses. Kami akan menghubungi Anda untuk konfirmasi.
            </p>

            <BookingSummaryCard
              customerName={customerName}
              date={date}
              startTime={startTime}
              endTime={endTime}
              totalPrice={calculateTotal()}
              shiftLabel={serviceType === "recording" ? shiftOptions.find(s => s.id === selectedShift)?.label : undefined}
              durationHours={serviceType === "studio_rental" ? calculateHours() : undefined}
            />

            <Button
              variant="hero"
              size="lg"
              className="w-full mt-6"
              onClick={() => navigate("/")}
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Kembali ke Beranda
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  // Payment Step
  if (step === "payment") {
    return (
      <div className="min-h-screen py-12 px-4">
        <div className="max-w-2xl mx-auto">
          <BookingProgress currentStep="payment" />

          <Button
            variant="ghost"
            onClick={() => setStep("form")}
            className="mb-6 hover-lift"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Kembali ke Form
          </Button>

          <div className="grid gap-6">
            <div className="animate-fade-in">
              <BookingSummaryCard
                customerName={customerName}
                date={date}
                startTime={startTime}
                endTime={endTime}
                totalPrice={calculateTotal()}
                shiftLabel={serviceType === "recording" ? shiftOptions.find(s => s.id === selectedShift)?.label : undefined}
                durationHours={serviceType === "studio_rental" ? calculateHours() : undefined}
                compact
              />
            </div>

            <Card className="glass-card p-6 animate-slide-up">
              <h2 className="text-xl font-bold mb-6 gradient-primary bg-clip-text text-transparent">
                Pilih Metode Pembayaran
              </h2>

              {paymentSettings.length > 0 ? (
                <PaymentMethodSelector
                  paymentSettings={paymentSettings}
                  selectedPayment={selectedPayment}
                  onSelect={setSelectedPayment}
                />
              ) : (
                <p className="text-muted-foreground text-center py-4">
                  Memuat metode pembayaran...
                </p>
              )}
            </Card>

            <Card className="glass-card p-6 animate-slide-up">
              <h2 className="text-xl font-bold mb-6 gradient-primary bg-clip-text text-transparent">
                Upload Bukti Pembayaran
              </h2>

              <div className="space-y-4">
                <div
                  className={cn(
                    "border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-200",
                    "hover:border-primary hover:bg-primary/5",
                    paymentProofPreview ? "border-primary bg-primary/5" : "border-border"
                  )}
                  onClick={() => document.getElementById("payment-proof")?.click()}
                >
                  {paymentProofPreview ? (
                    <div className="space-y-4">
                      <img
                        src={paymentProofPreview}
                        alt="Payment Proof"
                        className="max-h-48 mx-auto rounded-lg shadow-lg"
                      />
                      <p className="text-sm text-muted-foreground">
                        Klik untuk ganti foto
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="w-16 h-16 mx-auto rounded-full bg-primary/10 flex items-center justify-center">
                        <Upload className="w-8 h-8 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">Klik untuk upload</p>
                        <p className="text-sm text-muted-foreground">
                          PNG, JPG hingga 5MB
                        </p>
                      </div>
                    </div>
                  )}
                </div>
                <input
                  id="payment-proof"
                  type="file"
                  accept="image/*"
                  onChange={handlePaymentProofChange}
                  className="hidden"
                />
              </div>

              <Button
                variant="hero"
                size="lg"
                className="w-full mt-6"
                onClick={handleSubmitBooking}
                disabled={isSubmitting || !paymentProof}
              >
                {isSubmitting ? (
                  isUploading ? "Mengupload..." : "Memproses..."
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Konfirmasi Booking
                  </>
                )}
              </Button>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  // Form Step
  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <BookingProgress currentStep="form" />

        <Button
          variant="ghost"
          onClick={() => setStep("service")}
          className="mb-6 hover-lift"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Kembali Pilih Layanan
        </Button>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Schedule Calendar */}
          <Card className="glass-card p-6 animate-fade-in">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-14 h-14 rounded-2xl gradient-primary flex items-center justify-center shadow-glow">
                {serviceType === "recording" ? (
                  <Headphones className="w-7 h-7 text-primary-foreground" />
                ) : (
                  <Music className="w-7 h-7 text-primary-foreground" />
                )}
              </div>
              <div>
                <h2 className="text-2xl font-bold gradient-primary bg-clip-text text-transparent">
                  {serviceType === "recording" ? "Recording" : "Studio Rental"}
                </h2>
                <p className="text-primary font-semibold text-lg">
                  {serviceType === "recording" ? (
                    <>Rp {PRICE_PER_SHIFT.toLocaleString("id-ID")} <span className="text-sm text-muted-foreground font-normal">/ shift (6 jam)</span></>
                  ) : (
                    <>Rp {PRICE_PER_HOUR.toLocaleString("id-ID")} <span className="text-sm text-muted-foreground font-normal">/ jam</span></>
                  )}
                </p>
              </div>
            </div>

            <p className="text-muted-foreground mb-6 text-sm">
              {serviceType === "recording" 
                ? "Pilih shift yang sesuai untuk sesi recording Anda"
                : "Pilih tanggal dan waktu untuk sewa studio"
              }
            </p>

            {/* Calendar Navigation */}
            <div className="flex items-center justify-between mb-4 bg-muted/30 rounded-xl p-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setCalendarMonth(new Date(calendarMonth.setMonth(calendarMonth.getMonth() - 1)))}
                className="hover:bg-primary/10"
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>
              <h3 className="font-semibold text-lg">
                {format(calendarMonth, "MMMM yyyy", { locale: localeId })}
              </h3>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setCalendarMonth(new Date(calendarMonth.setMonth(calendarMonth.getMonth() + 1)))}
                className="hover:bg-primary/10"
              >
                <ChevronRight className="h-5 w-5" />
              </Button>
            </div>

            {/* Legend */}
            <div className="flex gap-4 mb-4 justify-center">
              {[
                { color: "bg-green-500", label: "Tersedia" },
                { color: "bg-yellow-500", label: "Sebagian" },
                { color: "bg-red-500", label: "Penuh" },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-2 text-xs">
                  <div className={cn("w-3 h-3 rounded-full", item.color)} />
                  <span className="text-muted-foreground">{item.label}</span>
                </div>
              ))}
            </div>

            {/* Calendar Grid */}
            <div className="grid grid-cols-7 gap-1 mb-6">
              {["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"].map((day) => (
                <div key={day} className="text-center text-xs font-medium text-muted-foreground py-2">
                  {day}
                </div>
              ))}
              
              {Array.from({ length: firstDayOfMonth }).map((_, i) => (
                <div key={`empty-${i}`} />
              ))}

              {calendarDays.map((day) => {
                const status = getDayStatus(day);
                const isSelected = date && format(date, "yyyy-MM-dd") === format(day, "yyyy-MM-dd");
                const isPast = day < new Date(new Date().setHours(0, 0, 0, 0));

                return (
                  <button
                    key={day.toISOString()}
                    onClick={() => {
                      if (!isPast && status !== "full") {
                        setDate(day);
                        setStartTime("");
                        setEndTime("");
                        setSelectedShift("");
                      }
                    }}
                    disabled={isPast || status === "full"}
                    className={cn(
                      "aspect-square rounded-lg flex flex-col items-center justify-center text-sm transition-all",
                      "hover:bg-primary/10 disabled:opacity-50 disabled:cursor-not-allowed",
                      isSelected && "ring-2 ring-primary bg-primary/20",
                      status === "available" && !isPast && "hover:scale-105",
                      status === "full" && "bg-red-500/10"
                    )}
                  >
                    <span className={cn(
                      "font-medium",
                      isPast && "text-muted-foreground"
                    )}>
                      {format(day, "d")}
                    </span>
                    {!isPast && (
                      <span className={cn(
                        "w-2 h-2 rounded-full mt-1",
                        status === "available" && "bg-green-500",
                        status === "partial" && "bg-yellow-500",
                        status === "full" && "bg-red-500"
                      )} />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Time/Shift Selection */}
            {date && (
              <div className="space-y-4 border-t pt-4">
                <h4 className="font-semibold flex items-center gap-2">
                  <Clock className="w-4 h-4 text-primary" />
                  {serviceType === "recording" ? "Pilih Shift" : "Pilih Waktu"}
                </h4>

                {serviceType === "recording" ? (
                  // Shift selection for recording
                  <div className="grid grid-cols-2 gap-3">
                    {shiftOptions.map((shift) => {
                      const isBooked = isShiftBooked(date, shift.id);
                      const isSelected = selectedShift === shift.id;

                      return (
                        <button
                          key={shift.id}
                          onClick={() => handleShiftSelect(shift.id)}
                          disabled={isBooked}
                          className={cn(
                            "p-4 rounded-xl border-2 transition-all text-left",
                            isSelected 
                              ? "border-primary bg-primary/10" 
                              : "border-border hover:border-primary/50",
                            isBooked && "opacity-50 cursor-not-allowed bg-muted"
                          )}
                        >
                          <p className="font-semibold">{shift.label}</p>
                          <p className="text-sm text-muted-foreground">{shift.description}</p>
                          {isBooked && (
                            <span className="text-xs text-red-500 mt-1 block">Sudah dibooking</span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  // Time selection for studio rental
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Mulai</Label>
                        <Select value={startTime} onValueChange={handleStartTimeChange}>
                          <SelectTrigger>
                            <SelectValue placeholder="Pilih jam mulai" />
                          </SelectTrigger>
                          <SelectContent>
                            {timeSlots.slice(0, -1).map((time) => {
                              const status = getSlotStatus(date, time);
                              return (
                                <SelectItem
                                  key={time}
                                  value={time}
                                  disabled={status === "booked"}
                                >
                                  {time} {status === "booked" && "(Booked)"}
                                </SelectItem>
                              );
                            })}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label>Selesai</Label>
                        <Select 
                          value={endTime} 
                          onValueChange={setEndTime}
                          disabled={!startTime}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Pilih jam selesai" />
                          </SelectTrigger>
                          <SelectContent>
                            {getAvailableEndTimes().map((time) => (
                              <SelectItem key={time} value={time}>
                                {time}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {startTime && endTime && (
                      <div className="bg-primary/10 rounded-xl p-4 text-center">
                        <p className="text-sm text-muted-foreground">Durasi</p>
                        <p className="text-2xl font-bold gradient-primary bg-clip-text text-transparent">
                          {calculateHours()} jam
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </Card>

          {/* Customer Info & Summary */}
          <div className="space-y-6">
            <Card className="glass-card p-6 animate-slide-up">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <User className="w-4 h-4 text-primary" />
                Informasi Pelanggan
              </h3>
              
              <form onSubmit={handleProceedToPayment} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nama Lengkap *</Label>
                  <Input
                    id="name"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Masukkan nama lengkap"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Nomor WhatsApp *</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="phone"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="08xxxxxxxxxx"
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email (Opsional)</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      placeholder="email@example.com"
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Catatan (Opsional)</Label>
                  <Textarea
                    id="notes"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Catatan tambahan..."
                    rows={3}
                  />
                </div>

                {/* Summary */}
                {date && ((serviceType === "recording" && selectedShift) || (serviceType === "studio_rental" && startTime && endTime)) && (
                  <BookingSummaryCard
                    customerName={customerName || "Nama Pelanggan"}
                    date={date}
                    startTime={startTime}
                    endTime={endTime}
                    totalPrice={calculateTotal()}
                    shiftLabel={serviceType === "recording" ? shiftOptions.find(s => s.id === selectedShift)?.label : undefined}
                    durationHours={serviceType === "studio_rental" ? calculateHours() : undefined}
                    compact
                  />
                )}

                <Button
                  type="submit"
                  variant="hero"
                  size="lg"
                  className="w-full mt-4"
                  disabled={
                    !date || 
                    !customerName || 
                    !customerPhone ||
                    (serviceType === "studio_rental" && (!startTime || !endTime)) ||
                    (serviceType === "recording" && !selectedShift)
                  }
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Lanjut ke Pembayaran
                </Button>
              </form>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
