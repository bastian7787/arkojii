import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Music, Mic, Radio, MapPin, Phone, Clock, MessageCircle, Star, Headphones, Video, Settings, Disc } from "lucide-react";
import arkojiLogo from "@/assets/arkoji-logo-new.jpg";

const mainServices = [
  {
    icon: Music,
    title: "Studio Rent",
    description: "Sewa studio rekaman dengan peralatan profesional untuk recording, latihan band, atau podcast.",
    price: "Rp 150.000 / jam",
    features: ["Full equipment", "Soundproof room", "Realtime calendar"],
    action: "booking"
  },
  {
    icon: Headphones,
    title: "Recording",
    description: "Recording profesional di studio dengan sistem booking shift (6 jam per shift).",
    price: "Rp 800.000 / shift",
    features: ["6 jam per shift", "Professional equipment", "Shift Pagi/Sore"],
    action: "booking"
  },
  {
    icon: Mic,
    title: "Vocal Class",
    description: "Professional vocal training untuk meningkatkan kemampuan menyanyi Anda.",
    price: "Contact admin",
    features: ["Personal assessment", "One-on-one training", "Flexible schedule"],
    action: "whatsapp"
  }
];

const otherServices = [
  {
    icon: Settings,
    title: "Vocal Arrangements & Directing",
    price: "Rp 1.000.000 / lagu",
    description: "Aransemen dan directing vokal profesional"
  },
  {
    icon: Radio,
    title: "Music Arrangements",
    price: "mulai Rp 1.500.000 / lagu",
    description: "Aransemen musik lengkap"
  },
  {
    icon: Disc,
    title: "Minus One / Instrumental",
    price: "mulai Rp 800.000 / lagu",
    description: "Pembuatan instrumental/minus one"
  },
  {
    icon: Settings,
    title: "Mixing & Mastering",
    price: "Rp 1.500.000 (masing-masing Rp 1.000.000)",
    description: "Mixing dan mastering berkualitas"
  },
  {
    icon: Video,
    title: "Video Cover Production",
    price: "Rp 2.500.000",
    description: "Produksi video cover (bawa file musik sendiri)"
  }
];

const operatingHours = [
  { day: "Monday", hours: "10:00 AM - 10:00 PM" },
  { day: "Tuesday", hours: "10:00 AM - 10:00 PM" },
  { day: "Wednesday", hours: "10:00 AM - 10:00 PM" },
  { day: "Thursday", hours: "10:00 AM - 10:00 PM" },
  { day: "Friday", hours: "10:00 AM - 10:00 PM" },
  { day: "Saturday", hours: "10:00 AM - 11:00 PM" },
  { day: "Sunday", hours: "Closed", closed: true }
];

export default function Index() {
  const navigate = useNavigate();

  const handleWhatsApp = (message?: string) => {
    const defaultMessage = message || "Halo, saya tertarik dengan layanan Arkoji Studio";
    const whatsappUrl = `https://wa.me/6282180007130?text=${encodeURIComponent(defaultMessage)}`;
    // Use location.href as fallback if window.open is blocked
    const newWindow = window.open(whatsappUrl, "_blank");
    if (!newWindow || newWindow.closed || typeof newWindow.closed === 'undefined') {
      window.location.href = whatsappUrl;
    }
  };

  const handleServiceClick = (service: typeof mainServices[0]) => {
    if (service.action === "whatsapp") {
      handleWhatsApp(`Halo, saya tertarik dengan layanan ${service.title}`);
    } else {
      navigate("/booking");
    }
  };

  return (
    <div className="min-h-screen relative">
      {/* Cyber Grid Background */}
      <div className="fixed inset-0 cyber-grid opacity-20 pointer-events-none" />
      
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4 overflow-hidden">
        <div className="absolute inset-0 gradient-hero opacity-60"></div>
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/30 via-transparent to-transparent"></div>
        
        {/* Animated Glow Orbs */}
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-primary/20 rounded-full blur-3xl animate-pulse-slow" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse-slow" style={{ animationDelay: '2s' }} />
        
        <div className="relative z-10 max-w-4xl mx-auto text-center space-y-8 animate-float">
          <div className="relative inline-block">
            <div className="absolute inset-0 gradient-primary rounded-2xl blur-xl opacity-50 animate-glow-pulse" />
            <img 
              src={arkojiLogo} 
              alt="Arkoji Studio" 
              className="relative w-32 h-32 md:w-40 md:h-40 mx-auto rounded-2xl shadow-neon object-cover"
            />
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold">
            <span className="neon-text">
              Arkoji Studio
            </span>
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto">
            Professional Music Studio di Jakarta Selatan. Recording, Vocal Class, dan Music Production.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              variant="hero"
              size="lg"
              onClick={() => navigate("/booking")}
              className="text-lg px-8 btn-glow hover-glow"
            >
              Book Studio
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={() => handleWhatsApp()}
              className="text-lg px-8 hover-lift"
            >
              <MessageCircle className="mr-2 h-5 w-5" />
              WhatsApp Us
            </Button>
          </div>
        </div>
      </section>

      {/* Main Services Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 neon-text">
              Our Services
            </h2>
            <p className="text-xl text-muted-foreground">
              Pilih layanan yang sesuai dengan kebutuhan Anda
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-16">
            {mainServices.map((service, index) => {
              const Icon = service.icon;
              return (
                <Card
                  key={index}
                  className="neon-card p-8 hover:shadow-neon transition-all duration-300 hover:-translate-y-2"
                >
                  <div className="mb-6">
                    <div className="relative w-16 h-16 mb-4">
                      <div className="absolute inset-0 gradient-primary rounded-2xl blur-md opacity-50" />
                      <div className="relative w-full h-full rounded-2xl gradient-primary flex items-center justify-center">
                        <Icon className="w-8 h-8 text-primary-foreground" />
                      </div>
                    </div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-2xl font-bold neon-text">{service.title}</h3>
                      <span className="text-primary font-semibold">{service.price}</span>
                    </div>
                    <p className="text-muted-foreground mb-4">{service.description}</p>
                    {service.title === "Vocal Class" && (
                      <p className="text-sm text-primary mb-4 italic">
                        Contact Ms Leona for personal vocal assessment
                      </p>
                    )}
                  </div>
                  
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-sm">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary mr-2 shadow-glow"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <Button
                    variant={service.action === "whatsapp" ? "accent" : "hero"}
                    className="w-full btn-glow"
                    onClick={() => handleServiceClick(service)}
                  >
                    {service.action === "whatsapp" ? (
                      <>
                        <MessageCircle className="mr-2 h-4 w-4" />
                        Contact via WhatsApp
                      </>
                    ) : (
                      "Book Now"
                    )}
                  </Button>
                </Card>
              );
            })}
          </div>

          {/* Other Services */}
          <div className="mt-20">
            <h3 className="text-3xl font-bold text-center mb-8 neon-text">Other Services</h3>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {otherServices.map((service, index) => {
                const Icon = service.icon;
                return (
                  <Card
                    key={index}
                    className="neon-card p-6 hover:shadow-elevated transition-all duration-300 cursor-pointer hover:-translate-y-1"
                    onClick={() => handleWhatsApp(`Halo, saya tertarik dengan layanan ${service.title}`)}
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-xl gradient-secondary flex items-center justify-center flex-shrink-0">
                        <Icon className="w-6 h-6 text-primary-foreground" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold mb-1">{service.title}</h4>
                        <p className="text-sm text-muted-foreground mb-2">{service.description}</p>
                        <p className="text-primary font-medium text-sm">{service.price}</p>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
            <p className="text-center text-muted-foreground mt-6 text-sm">
              Klik layanan untuk menghubungi via WhatsApp
            </p>
          </div>
        </div>
      </section>

      {/* Pricelist Section */}
      <section className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent pointer-events-none" />
        <div className="max-w-4xl mx-auto relative">
          <h2 className="text-4xl font-bold text-center mb-12 neon-text">Pricelist</h2>
          <Card className="neon-card p-8 shadow-elevated">
            <div className="space-y-4">
              <div className="flex justify-between items-center py-3 border-b border-border">
                <span className="font-medium">Studio Rent</span>
                <span className="text-primary font-semibold">Rp 150.000 / jam</span>
              </div>
              <div className="flex justify-between items-center py-3 border-b border-border">
                <span className="font-medium">Vocal Class</span>
                <span className="text-muted-foreground italic">Contact Admin</span>
              </div>
              <div className="flex justify-between items-center py-3 border-b border-border">
                <span className="font-medium">Vocal Arrangements & Directing</span>
                <span className="text-primary font-semibold">Rp 1.000.000 / lagu</span>
              </div>
              <div className="flex justify-between items-center py-3 border-b border-border">
                <span className="font-medium">Music Arrangements</span>
                <span className="text-primary font-semibold">mulai Rp 1.500.000 / lagu</span>
              </div>
              <div className="flex justify-between items-center py-3 border-b border-border">
                <span className="font-medium">Minus One / Instrumental</span>
                <span className="text-primary font-semibold">mulai Rp 800.000 / lagu</span>
              </div>
              <div className="flex justify-between items-center py-3 border-b border-border">
                <span className="font-medium">Recording</span>
                <span className="text-primary font-semibold">Rp 800.000 / shift (6 jam)</span>
              </div>
              <div className="flex justify-between items-center py-3 border-b border-border">
                <div>
                  <span className="font-medium">Mixing & Mastering</span>
                  <p className="text-xs text-muted-foreground">masing-masing Rp 1.000.000</p>
                </div>
                <span className="text-primary font-semibold">Rp 1.500.000</span>
              </div>
              <div className="flex justify-between items-center py-3">
                <div>
                  <span className="font-medium">Video Cover Production</span>
                  <p className="text-xs text-muted-foreground">bring your own music file</p>
                </div>
                <span className="text-primary font-semibold">Rp 2.500.000</span>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="py-20 px-4 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-accent/5 to-transparent pointer-events-none" />
        <div className="max-w-7xl mx-auto text-center relative z-10">
          <h2 className="text-4xl font-bold mb-4 neon-text">Customer Reviews</h2>
          <p className="text-muted-foreground mb-8">Lihat pengalaman pelanggan kami</p>
          <Button variant="outline" onClick={() => navigate("/reviews")} className="hover-glow btn-glow">
            <Star className="mr-2 h-4 w-4" />
            Lihat Semua Review
          </Button>
        </div>
      </section>

      {/* Contact & Hours Section */}
      <section className="py-20 px-4 bg-card/50">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div className="space-y-8">
              <div>
                <h2 className="text-4xl font-bold mb-6">Contact Us</h2>
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <MapPin className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold mb-2">Address</h3>
                      <p className="text-muted-foreground">
                        Jl. Bangka VIII A No.4, RT.1/RW.12, Pela Mampang<br />
                        Kec. Mampang Prpt., Kota Jakarta Selatan<br />
                        DKI Jakarta 12720
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <Phone className="w-6 h-6 text-primary flex-shrink-0" />
                    <div>
                      <h3 className="font-semibold mb-2">Phone</h3>
                      <a
                        href="tel:+6282180007130"
                        className="text-muted-foreground hover:text-primary transition-colors"
                      >
                        0821-8000-7130
                      </a>
                    </div>
                  </div>

                  <Button
                    variant="accent"
                    size="lg"
                    onClick={() => handleWhatsApp()}
                    className="w-full"
                  >
                    <MessageCircle className="mr-2 h-5 w-5" />
                    Chat via WhatsApp
                  </Button>
                </div>
              </div>

              {/* Operating Hours */}
              <Card className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Clock className="w-6 h-6 text-primary" />
                  <h3 className="text-xl font-bold">Operating Hours</h3>
                </div>
                <div className="space-y-2">
                  {operatingHours.map((schedule, idx) => (
                    <div
                      key={idx}
                      className={`flex justify-between py-2 border-b border-border/50 last:border-0 ${
                        schedule.closed ? "text-muted-foreground" : ""
                      }`}
                    >
                      <span className="font-medium">{schedule.day}</span>
                      <span className={schedule.closed ? "text-destructive" : ""}>
                        {schedule.hours}
                      </span>
                    </div>
                  ))}
                </div>
              </Card>
            </div>

            {/* Map */}
            <div className="space-y-4">
              <h2 className="text-4xl font-bold">Find Us</h2>
              <Card className="overflow-hidden shadow-elevated">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.1!2d106.8242!3d-6.2533!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f3e95d7c55b7%3A0x7c54f8d7b3c8e9a1!2sJl.%20Bangka%20VIII%20A%20No.4%2C%20Pela%20Mampang%2C%20Mampang%20Prapatan%2C%20South%20Jakarta%20City%2C%20Jakarta!5e0!3m2!1sen!2sid!4v1701856800000!5m2!1sen!2sid"
                  width="100%"
                  height="450"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Arkoji Studio Location"
                  className="w-full"
                ></iframe>
              </Card>
              <p className="text-sm text-muted-foreground text-center">
                Klik map untuk buka di Google Maps dan dapatkan arah ke studio
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <Card className="p-12 gradient-hero shadow-elevated">
            <h2 className="text-4xl font-bold mb-4">Ready to Create?</h2>
            <p className="text-xl text-muted-foreground mb-8">
              Book your session sekarang dan wujudkan karya musik terbaik Anda
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                variant="hero"
                size="lg"
                onClick={() => navigate("/booking")}
                className="text-lg px-8"
              >
                Book Studio
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={() => navigate("/auth")}
                className="text-lg px-8"
              >
                Admin Login
              </Button>
            </div>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-border">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-3">
              <img src={arkojiLogo} alt="Arkoji" className="w-8 h-8 rounded object-cover" />
              <p className="text-muted-foreground">&copy; 2024 Arkoji Studio. All rights reserved.</p>
            </div>
            <div className="flex gap-4 flex-wrap justify-center">
              <Button variant="ghost" size="sm" onClick={() => navigate("/about")}>
                About Us
              </Button>
              <Button variant="ghost" size="sm" onClick={() => navigate("/booking")}>
                Booking
              </Button>
              <Button variant="ghost" size="sm" onClick={() => navigate("/reviews")}>
                Reviews
              </Button>
              <Button variant="ghost" size="sm" onClick={() => navigate("/auth")}>
                Admin
              </Button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
