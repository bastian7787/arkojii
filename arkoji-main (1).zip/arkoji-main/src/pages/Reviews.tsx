import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Star, ArrowLeft, MapPin, Sparkles } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { id } from "date-fns/locale";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ReviewForm } from "@/components/reviews/ReviewForm";

interface Review {
  id: string;
  customer_name: string;
  service_type: string;
  rating: number;
  content: string;
  image_url: string | null;
  created_at: string;
}

const serviceLabels: Record<string, string> = {
  vocal_class: "Vocal Class",
  studio_rental: "Studio Rental",
  another_service: "Another Service",
  music_production: "Music Production",
  recording: "Recording"
};

const serviceColors: Record<string, string> = {
  vocal_class: "bg-purple-500/20 text-purple-400 border-purple-500/30",
  studio_rental: "bg-primary/20 text-primary border-primary/30",
  another_service: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  music_production: "bg-green-500/20 text-green-400 border-green-500/30",
  recording: "bg-orange-500/20 text-orange-400 border-orange-500/30"
};

export default function Reviews() {
  const navigate = useNavigate();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadReviews();
  }, []);

  const loadReviews = async () => {
    const { data, error } = await supabase
      .from("reviews")
      .select("*")
      .eq("is_published", true)
      .order("created_at", { ascending: false });

    if (!error && data) {
      setReviews(data);
    }
    setIsLoading(false);
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center gap-0.5">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            className={`w-4 h-4 ${i < rating ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground/30"}`}
          />
        ))}
        <span className="ml-2 text-sm font-medium">{rating}.0</span>
      </div>
    );
  };

  const getAverageRating = () => {
    if (reviews.length === 0) return 0;
    const sum = reviews.reduce((acc, review) => acc + review.rating, 0);
    return (sum / reviews.length).toFixed(1);
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Enhanced Futuristic Background */}
      <div className="fixed inset-0 cyber-grid opacity-20 pointer-events-none" />
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-transparent to-transparent pointer-events-none" />
      
      {/* Animated Glow Orbs */}
      <div className="fixed top-20 right-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl animate-pulse-slow pointer-events-none" />
      <div className="fixed bottom-20 left-10 w-64 h-64 bg-accent/10 rounded-full blur-3xl animate-pulse-slow pointer-events-none" style={{ animationDelay: '1.5s' }} />
      
      {/* Header */}
      <header className="sticky top-0 z-50 glass-dark border-b border-primary/20">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/")}
            className="hover:bg-primary/10"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary animate-pulse" />
            <h1 className="font-bold text-xl neon-text">Customer Reviews</h1>
          </div>
          <div className="w-10" />
        </div>
      </header>

      {/* Summary Section */}
      <div className="max-w-4xl mx-auto px-4 py-8 relative z-10">
        {/* Add Review Button */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-2xl font-bold">Pengalaman Pelanggan</h2>
            <p className="text-muted-foreground text-sm">Bagikan pengalaman Anda bersama kami</p>
          </div>
          <ReviewForm onSuccess={loadReviews} />
        </div>

        <Card className="neon-card p-6 mb-8 animated-border">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="text-center">
              <div className="text-6xl font-bold neon-text drop-shadow-[0_0_20px_rgba(239,68,68,0.5)]">{getAverageRating()}</div>
              <div className="flex justify-center mt-2">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={`w-6 h-6 ${i < Math.round(Number(getAverageRating())) ? "fill-yellow-400 text-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.5)]" : "text-muted-foreground/30"}`}
                  />
                ))}
              </div>
              <p className="text-sm text-muted-foreground mt-2">{reviews.length} reviews</p>
            </div>
            <div className="flex-1 space-y-2 w-full">
              {[5, 4, 3, 2, 1].map((star) => {
                const count = reviews.filter(r => r.rating === star).length;
                const percentage = reviews.length > 0 ? (count / reviews.length) * 100 : 0;
                return (
                  <div key={star} className="flex items-center gap-2">
                    <span className="text-sm w-3 font-medium">{star}</span>
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <div className="flex-1 h-3 bg-muted/50 rounded-full overflow-hidden">
                      <div 
                        className="h-full gradient-primary transition-all duration-700 shadow-glow"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <span className="text-xs text-muted-foreground w-6 text-right">{count}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </Card>

        {/* Reviews List */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : reviews.length === 0 ? (
          <Card className="neon-card p-12 text-center">
            <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
              <Star className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="font-semibold text-xl mb-2">Belum Ada Review</h3>
            <p className="text-muted-foreground">
              Jadilah yang pertama memberikan review!
            </p>
          </Card>
        ) : (
          <div className="space-y-4">
            {reviews.map((review, index) => (
              <Card 
                key={review.id} 
                className="neon-card p-6 animate-fade-in hover:shadow-neon transition-all duration-300"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {/* Review Header */}
                <div className="flex items-start gap-4 mb-4">
                  <Avatar className="w-14 h-14 ring-2 ring-primary/50 shadow-glow">
                    {review.image_url ? (
                      <AvatarImage src={review.image_url} alt={review.customer_name} />
                    ) : null}
                    <AvatarFallback className="gradient-primary text-primary-foreground font-bold text-lg">
                      {review.customer_name.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-lg truncate">{review.customer_name}</h3>
                    <div className="flex flex-wrap items-center gap-2 mt-1">
                      {renderStars(review.rating)}
                      <span className="text-muted-foreground">•</span>
                      <span className="text-sm text-muted-foreground">
                        {formatDistanceToNow(new Date(review.created_at), { addSuffix: true, locale: id })}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Service Badge */}
                <div className="mb-4">
                  <Badge 
                    variant="outline" 
                    className={`${serviceColors[review.service_type] || "bg-muted"} border shadow-sm`}
                  >
                    <MapPin className="w-3 h-3 mr-1" />
                    {serviceLabels[review.service_type] || review.service_type}
                  </Badge>
                </div>

                {/* Review Content */}
                <div className="relative">
                  <span className="absolute -top-2 -left-1 text-4xl text-primary/20 font-serif">"</span>
                  <p className="text-foreground/90 leading-relaxed pl-4 italic">
                    {review.content}
                  </p>
                  <span className="text-4xl text-primary/20 font-serif">"</span>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Bottom spacing */}
      <div className="h-20" />
    </div>
  );
}
