import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MapPin, Phone, Clock, MessageCircle, Mail } from "lucide-react";
import arkojiLogo from "@/assets/arkoji-logo-new.jpg";
import { useNavigate } from "react-router-dom";

const operatingHours = [
  { day: "Monday", hours: "10:00 AM - 10:00 PM" },
  { day: "Tuesday", hours: "10:00 AM - 10:00 PM" },
  { day: "Wednesday", hours: "10:00 AM - 10:00 PM" },
  { day: "Thursday", hours: "10:00 AM - 10:00 PM" },
  { day: "Friday", hours: "10:00 AM - 10:00 PM" },
  { day: "Saturday", hours: "10:00 AM - 11:00 PM" },
  { day: "Sunday", hours: "Closed", closed: true }
];

export default function About() {
  const navigate = useNavigate();

  const handleWhatsApp = () => {
    const whatsappUrl = "https://wa.me/6282180007130";
    const newWindow = window.open(whatsappUrl, "_blank");
    if (!newWindow || newWindow.closed || typeof newWindow.closed === 'undefined') {
      window.location.href = whatsappUrl;
    }
  };

  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-background/80 backdrop-blur-lg border-b border-border z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <button onClick={() => navigate("/")} className="flex items-center gap-3">
            <img src={arkojiLogo} alt="Arkoji Studio" className="h-12 w-12 rounded-lg" />
            <span className="text-xl font-bold">Arkoji Studio</span>
          </button>
          <div className="flex gap-4">
            <Button variant="ghost" onClick={() => navigate("/")}>
              Home
            </Button>
            <Button variant="ghost" onClick={() => navigate("/booking")}>
              Booking
            </Button>
            <Button variant="outline" onClick={handleWhatsApp}>
              <MessageCircle className="mr-2 h-4 w-4" />
              WhatsApp
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section with Logo */}
      <section className="pt-32 pb-20 px-4">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <div className="flex justify-center mb-8 animate-float">
            <img 
              src={arkojiLogo} 
              alt="Arkoji Studio Logo" 
              className="h-48 w-48 rounded-3xl shadow-elevated"
            />
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold">
            <span className="gradient-primary bg-clip-text text-transparent">
              About Arkoji Studio
            </span>
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Professional music studio di Jakarta Selatan yang menyediakan layanan recording, 
            vocal class, dan music production dengan peralatan dan instruktur berkualitas tinggi.
          </p>
        </div>
      </section>

      {/* Tentang Studio */}
      <section className="py-20 px-4 bg-gradient-to-br from-primary/10 to-accent/10">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-12">
            <span className="gradient-primary bg-clip-text text-transparent">
              Tentang Arkoji Studio
            </span>
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="p-8 hover:shadow-elevated transition-all">
              <h3 className="text-2xl font-bold mb-4">Visi Kami</h3>
              <p className="text-muted-foreground leading-relaxed">
                Menjadi studio musik terdepan di Jakarta Selatan yang menghadirkan pengalaman recording, 
                vocal training, dan music production berkualitas profesional dengan teknologi terkini dan 
                suasana yang nyaman dan inspiratif.
              </p>
            </Card>
            
            <Card className="p-8 hover:shadow-elevated transition-all">
              <h3 className="text-2xl font-bold mb-4">Misi Kami</h3>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">✓</span>
                  <span>Menyediakan layanan recording berkualitas tinggi dengan peralatan profesional</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">✓</span>
                  <span>Mengembangkan talenta vokal melalui kelas yang terstruktur dan menyenangkan</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">✓</span>
                  <span>Membantu musisi mewujudkan karya musik terbaik mereka</span>
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </section>

      {/* Fasilitas */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-12">
            <span className="gradient-primary bg-clip-text text-transparent">
              Fasilitas Studio
            </span>
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="p-6 hover:shadow-elevated transition-all text-center">
              <div className="w-16 h-16 mx-auto rounded-xl gradient-primary flex items-center justify-center mb-4">
                <span className="text-3xl">🎤</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Ruang Recording</h3>
              <p className="text-muted-foreground">
                Ruang kedap suara dengan akustik optimal untuk hasil recording terbaik
              </p>
            </Card>

            <Card className="p-6 hover:shadow-elevated transition-all text-center">
              <div className="w-16 h-16 mx-auto rounded-xl gradient-primary flex items-center justify-center mb-4">
                <span className="text-3xl">🎹</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Peralatan Pro</h3>
              <p className="text-muted-foreground">
                Microphone, audio interface, dan software DAW profesional
              </p>
            </Card>

            <Card className="p-6 hover:shadow-elevated transition-all text-center">
              <div className="w-16 h-16 mx-auto rounded-xl gradient-primary flex items-center justify-center mb-4">
                <span className="text-3xl">☕</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Ruang Tunggu</h3>
              <p className="text-muted-foreground">
                Ruang tunggu nyaman dengan WiFi gratis dan minuman
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-20 px-4 bg-card/50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16">Contact Information</h2>
          
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {/* Address Card */}
            <Card className="p-8 hover:shadow-elevated transition-all">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-3">Address</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Jl. Bangka VIII A No.4, RT.1/RW.12<br />
                    Pela Mampang, Kec. Mampang Prpt.<br />
                    Kota Jakarta Selatan<br />
                    Daerah Khusus Ibukota Jakarta 12720
                  </p>
                </div>
              </div>
            </Card>

            {/* Phone Card */}
            <Card className="p-8 hover:shadow-elevated transition-all">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6 text-white" />
                </div>
                <div className="w-full">
                  <h3 className="text-2xl font-bold mb-3">Phone</h3>
                  <a
                    href="tel:+6282180007130"
                    className="text-muted-foreground hover:text-primary transition-colors text-lg block mb-4"
                  >
                    0821-8000-7130
                  </a>
                  <Button
                    variant="accent"
                    onClick={handleWhatsApp}
                    className="w-full"
                  >
                    <MessageCircle className="mr-2 h-4 w-4" />
                    Chat via WhatsApp
                  </Button>
                </div>
              </div>
            </Card>
          </div>

          {/* Operating Hours */}
          <Card className="p-8 max-w-2xl mx-auto">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl font-bold">Operating Hours</h3>
            </div>
            <div className="space-y-3">
              {operatingHours.map((schedule, idx) => (
                <div
                  key={idx}
                  className={`flex justify-between py-3 border-b border-border/50 last:border-0 ${
                    schedule.closed ? "text-muted-foreground" : ""
                  }`}
                >
                  <span className="font-medium text-lg">{schedule.day}</span>
                  <span className={`text-lg ${schedule.closed ? "text-destructive font-semibold" : ""}`}>
                    {schedule.hours}
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Find Us</h2>
            <p className="text-xl text-muted-foreground">
              Lokasi strategis di Jakarta Selatan, mudah diakses dari berbagai area
            </p>
          </div>
          
          <Card className="overflow-hidden shadow-elevated max-w-5xl mx-auto">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.1!2d106.8242!3d-6.2533!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f3e95d7c55b7%3A0x7c54f8d7b3c8e9a1!2sJl.%20Bangka%20VIII%20A%20No.4%2C%20Pela%20Mampang%2C%20Mampang%20Prapatan%2C%20South%20Jakarta%20City%2C%20Jakarta!5e0!3m2!1sen!2sid!4v1701856800000!5m2!1sen!2sid"
              width="100%"
              height="500"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Arkoji Studio Location"
              className="w-full"
            ></iframe>
          </Card>
          <p className="text-center text-muted-foreground mt-4">
            Klik map untuk membuka di Google Maps dan dapatkan arah ke studio kami
          </p>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-card/50">
        <div className="max-w-4xl mx-auto">
          <Card className="p-12 gradient-hero shadow-elevated text-center">
            <h2 className="text-4xl font-bold mb-4">Ready to Start Your Music Journey?</h2>
            <p className="text-xl text-muted-foreground mb-8">
              Hubungi kami sekarang atau langsung booking session Anda
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                variant="hero"
                size="lg"
                onClick={() => navigate("/booking")}
                className="text-lg px-8"
              >
                Book Now
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={handleWhatsApp}
                className="text-lg px-8"
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                Contact via WhatsApp
              </Button>
            </div>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-border">
        <div className="max-w-7xl mx-auto text-center text-muted-foreground">
          <p>&copy; 2024 Arkoji Studio. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
