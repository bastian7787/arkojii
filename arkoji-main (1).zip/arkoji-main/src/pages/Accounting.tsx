import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { format, startOfMonth, endOfMonth } from "date-fns";
import { id as localeId } from "date-fns/locale";
import { ArrowLeft, Plus, TrendingUp, TrendingDown, Calendar, DollarSign, FileText, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

interface AccountingEntry {
  id: string;
  entry_date: string;
  entry_type: "income" | "expense";
  category: string;
  description: string;
  amount: number;
  notes: string | null;
  created_at: string;
}

interface BookingSummary {
  total: number;
  confirmed: number;
  pending: number;
  cancelled: number;
  byType: Record<string, number>;
}

const incomeCategories = ["Booking Studio", "Vocal Class", "Another Service", "Lainnya"];
const expenseCategories = ["Listrik", "Internet", "Peralatan", "Gaji", "Maintenance", "Lainnya"];

export default function Accounting() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [entries, setEntries] = useState<AccountingEntry[]>([]);
  const [bookingSummary, setBookingSummary] = useState<BookingSummary | null>(null);
  const [selectedMonth, setSelectedMonth] = useState(new Date());
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  // Form state
  const [entryDate, setEntryDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [entryType, setEntryType] = useState<"income" | "expense">("income");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [notes, setNotes] = useState("");

  useEffect(() => {
    checkAdminAndLoad();
  }, []);

  useEffect(() => {
    if (isAdmin) {
      loadData();
    }
  }, [selectedMonth, isAdmin]);

  const checkAdminAndLoad = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error("Silakan login terlebih dahulu");
        navigate("/auth");
        return;
      }

      const { data: roleData, error: roleError } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .eq("role", "admin")
        .maybeSingle();

      if (roleError || !roleData) {
        toast.error("Anda tidak memiliki akses admin");
        navigate("/");
        return;
      }

      setIsAdmin(true);
    } catch (error) {
      console.error("Error:", error);
      navigate("/");
    } finally {
      setIsLoading(false);
    }
  };

  const loadData = async () => {
    const start = startOfMonth(selectedMonth);
    const end = endOfMonth(selectedMonth);
    const startStr = format(start, "yyyy-MM-dd");
    const endStr = format(end, "yyyy-MM-dd");

    // Load accounting entries
    const { data: entriesData } = await supabase
      .from("accounting_entries")
      .select("*")
      .gte("entry_date", startStr)
      .lte("entry_date", endStr)
      .order("entry_date", { ascending: false });

    if (entriesData) {
      setEntries(entriesData as AccountingEntry[]);
    }

    // Load booking summary
    const { data: bookingsData } = await supabase
      .from("bookings")
      .select("status, booking_type")
      .gte("booking_date", startStr)
      .lte("booking_date", endStr);

    if (bookingsData) {
      const summary: BookingSummary = {
        total: bookingsData.length,
        confirmed: bookingsData.filter(b => b.status === "confirmed").length,
        pending: bookingsData.filter(b => b.status === "pending").length,
        cancelled: bookingsData.filter(b => b.status === "cancelled").length,
        byType: {}
      };

      bookingsData.forEach(b => {
        summary.byType[b.booking_type] = (summary.byType[b.booking_type] || 0) + 1;
      });

      setBookingSummary(summary);
    }
  };

  const resetForm = () => {
    setEntryDate(format(new Date(), "yyyy-MM-dd"));
    setEntryType("income");
    setCategory("");
    setDescription("");
    setAmount("");
    setNotes("");
  };

  const handleSubmit = async () => {
    if (!category || !description || !amount) {
      toast.error("Mohon isi semua field yang diperlukan");
      return;
    }

    const { data: { user } } = await supabase.auth.getUser();

    const { error } = await supabase
      .from("accounting_entries")
      .insert({
        entry_date: entryDate,
        entry_type: entryType,
        category,
        description,
        amount: parseFloat(amount),
        notes: notes || null,
        created_by: user?.id
      });

    if (error) {
      toast.error("Gagal menyimpan data");
      return;
    }

    toast.success("Data berhasil disimpan");
    setIsDialogOpen(false);
    resetForm();
    loadData();
  };

  const deleteEntry = async (id: string) => {
    if (!confirm("Yakin ingin menghapus data ini?")) return;

    const { error } = await supabase
      .from("accounting_entries")
      .delete()
      .eq("id", id);

    if (error) {
      toast.error("Gagal menghapus data");
      return;
    }

    toast.success("Data berhasil dihapus");
    loadData();
  };

  const totalIncome = entries.filter(e => e.entry_type === "income").reduce((sum, e) => sum + Number(e.amount), 0);
  const totalExpense = entries.filter(e => e.entry_type === "expense").reduce((sum, e) => sum + Number(e.amount), 0);
  const netProfit = totalIncome - totalExpense;

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0
    }).format(value);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAdmin) return null;

  // Check if today is the 25th
  const today = new Date();
  const isReportDay = today.getDate() === 25;

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <Button variant="ghost" onClick={() => navigate("/admin")} className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Kembali ke Dashboard
        </Button>

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-4xl font-bold gradient-primary bg-clip-text text-transparent">
              Pembukuan
            </h1>
            <p className="text-muted-foreground mt-2">
              Laporan keuangan bulanan
              {isReportDay && (
                <span className="ml-2 text-primary font-medium">
                  📅 Hari laporan bulanan!
                </span>
              )}
            </p>
          </div>

          <div className="flex gap-2">
            <Input
              type="month"
              value={format(selectedMonth, "yyyy-MM")}
              onChange={(e) => setSelectedMonth(new Date(e.target.value + "-01"))}
              className="w-40"
            />
            
            <Dialog open={isDialogOpen} onOpenChange={(open) => {
              setIsDialogOpen(open);
              if (!open) resetForm();
            }}>
              <DialogTrigger asChild>
                <Button variant="hero">
                  <Plus className="mr-2 h-4 w-4" />
                  Tambah Data
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Tambah Data Keuangan</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label>Tanggal</Label>
                    <Input
                      type="date"
                      value={entryDate}
                      onChange={(e) => setEntryDate(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Tipe</Label>
                    <Select value={entryType} onValueChange={(v) => {
                      setEntryType(v as "income" | "expense");
                      setCategory("");
                    }}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="income">Pemasukan</SelectItem>
                        <SelectItem value="expense">Pengeluaran</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Kategori *</Label>
                    <Select value={category} onValueChange={setCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih kategori" />
                      </SelectTrigger>
                      <SelectContent>
                        {(entryType === "income" ? incomeCategories : expenseCategories).map((cat) => (
                          <SelectItem key={cat} value={cat}>
                            {cat}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Deskripsi *</Label>
                    <Input
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="Deskripsi transaksi"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Jumlah (Rp) *</Label>
                    <Input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Catatan (Optional)</Label>
                    <Textarea
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Catatan tambahan..."
                      rows={2}
                    />
                  </div>

                  <Button onClick={handleSubmit} className="w-full" variant="hero">
                    Simpan
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Pemasukan</p>
                <p className="text-xl font-bold text-green-500">{formatCurrency(totalIncome)}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-red-500/20 flex items-center justify-center">
                <TrendingDown className="w-5 h-5 text-red-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Pengeluaran</p>
                <p className="text-xl font-bold text-red-500">{formatCurrency(totalExpense)}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Laba Bersih</p>
                <p className={`text-xl font-bold ${netProfit >= 0 ? "text-green-500" : "text-red-500"}`}>
                  {formatCurrency(netProfit)}
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-secondary/20 flex items-center justify-center">
                <Calendar className="w-5 h-5 text-secondary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Booking</p>
                <p className="text-xl font-bold">{bookingSummary?.total || 0}</p>
              </div>
            </div>
          </Card>
        </div>

        <Tabs defaultValue="transactions" className="space-y-6">
          <TabsList>
            <TabsTrigger value="transactions">Transaksi</TabsTrigger>
            <TabsTrigger value="booking-report">Laporan Booking</TabsTrigger>
          </TabsList>

          <TabsContent value="transactions">
            {entries.length === 0 ? (
              <Card className="p-12 text-center">
                <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Belum ada data transaksi</p>
              </Card>
            ) : (
              <div className="space-y-3">
                {entries.map((entry) => (
                  <Card key={entry.id} className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          entry.entry_type === "income" ? "bg-green-500/20" : "bg-red-500/20"
                        }`}>
                          {entry.entry_type === "income" ? (
                            <TrendingUp className="w-5 h-5 text-green-500" />
                          ) : (
                            <TrendingDown className="w-5 h-5 text-red-500" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium">{entry.description}</p>
                          <p className="text-sm text-muted-foreground">
                            {entry.category} • {format(new Date(entry.entry_date), "d MMM yyyy", { locale: localeId })}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <p className={`font-bold ${entry.entry_type === "income" ? "text-green-500" : "text-red-500"}`}>
                          {entry.entry_type === "income" ? "+" : "-"}{formatCurrency(Number(entry.amount))}
                        </p>
                        <Button variant="ghost" size="icon" onClick={() => deleteEntry(entry.id)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="booking-report">
            <Card className="p-6">
              <h3 className="font-semibold mb-4">
                Laporan Booking - {format(selectedMonth, "MMMM yyyy", { locale: localeId })}
              </h3>
              
              {bookingSummary ? (
                <div className="space-y-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 bg-muted/50 rounded-lg">
                      <p className="text-2xl font-bold">{bookingSummary.total}</p>
                      <p className="text-sm text-muted-foreground">Total Booking</p>
                    </div>
                    <div className="text-center p-4 bg-green-500/10 rounded-lg">
                      <p className="text-2xl font-bold text-green-500">{bookingSummary.confirmed}</p>
                      <p className="text-sm text-muted-foreground">Confirmed</p>
                    </div>
                    <div className="text-center p-4 bg-yellow-500/10 rounded-lg">
                      <p className="text-2xl font-bold text-yellow-500">{bookingSummary.pending}</p>
                      <p className="text-sm text-muted-foreground">Pending</p>
                    </div>
                    <div className="text-center p-4 bg-red-500/10 rounded-lg">
                      <p className="text-2xl font-bold text-red-500">{bookingSummary.cancelled}</p>
                      <p className="text-sm text-muted-foreground">Cancelled</p>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium mb-3">Berdasarkan Tipe Layanan</h4>
                    <div className="space-y-2">
                      {Object.entries(bookingSummary.byType).map(([type, count]) => (
                        <div key={type} className="flex justify-between items-center p-3 bg-muted/30 rounded-lg">
                          <span className="capitalize">{type.replace("_", " ")}</span>
                          <span className="font-medium">{count} booking</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-8">Tidak ada data booking</p>
              )}
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}