
# Rencana Redesign Arkoji Studio

## Ringkasan Perubahan
Tiga area utama yang akan diperbarui:
1. Halaman Review - ubah ke style Google Reviews (tanpa likes)
2. Design Website - upgrade ke tampilan futuristik
3. Payment Methods - hapus GoPay/ShopeePay, tambah nomor kontak baru, tetap BCA

---

## 1. Halaman Review - Google Reviews Style

### Perubahan Visual
- Hapus fitur likes, comments, share, dan bookmark (Instagram-style elements)
- Tampilan card-based seperti Google Reviews dengan:
  - Rating stars yang lebih besar dan prominent
  - Nama reviewer dengan avatar/initial
  - Tanggal review
  - Konten review dengan format bersih
  - Badge layanan yang digunakan

### Komponen yang Dihapus
- Heart/Like button dan counter
- Comment button
- Share button  
- Bookmark button
- Stories-like filter di atas

### Layout Baru
```text
+------------------------------------------+
|  [Avatar] Nama Customer                  |
|  ★★★★☆  4.0  •  2 hari yang lalu        |
|  Studio Rental                           |
|                                          |
|  "Review content goes here..."           |
+------------------------------------------+
```

---

## 2. Design Futuristik

### Perubahan CSS Variables
- Tambah efek neon glow yang lebih intense
- Gradient baru dengan efek cyberpunk (red + cyan accent)
- Tambah pattern grid/lines sebagai background
- Border glow effects pada cards

### Efek Baru yang Ditambahkan
- Animated gradient borders
- Neon text effects untuk headings
- Scan-line overlay effect (optional)
- Particle/grid background pattern
- Hover effects dengan glow yang lebih dramatis

### Komponen yang Diperbarui
- Hero section dengan animated background
- Cards dengan glassmorphism + neon border
- Buttons dengan hover glow effect
- Typography dengan neon/glow style

---

## 3. Payment Methods

### Database Update
Insert 2 payment methods ke tabel `payment_settings`:

| Payment Name | Type | Account Number | Account Holder |
|--------------|------|----------------|----------------|
| BCA | bank_transfer | 0331722331 | LEONA |
| Kontak Pembayaran | contact | 087811132004 | - |

### Perubahan UI
- Hapus ShopeePay dan GoPay dari pilihan
- Tampilkan BCA sebagai opsi transfer bank
- Tambah nomor kontak untuk konfirmasi pembayaran
- Update PaymentMethodSelector component untuk handle type "contact"

---

## Technical Details

### Files yang Akan Dimodifikasi

1. **src/pages/Reviews.tsx**
   - Redesign ke Google Reviews style
   - Hapus semua social interaction (likes, comments, share, bookmark)
   - Simplify ke card-based layout dengan rating focus

2. **src/index.css**
   - Tambah CSS variables untuk efek futuristik
   - Neon glow utilities
   - Grid/cyber pattern background
   - Animated gradient border classes

3. **src/pages/Index.tsx**
   - Apply futuristic styling ke Hero section
   - Update cards dengan neon effects
   - Add background pattern/grid

4. **src/components/booking/PaymentMethodSelector.tsx**
   - Tambah icon dan handling untuk type "contact"
   - Update display untuk nomor telepon

5. **src/pages/BookingUnified.tsx**
   - Update payment section untuk tampilkan nomor kontak

### Database Migration
- Insert BCA payment setting dengan nomor rekening existing (0331722331, a.n. LEONA)
- Insert contact payment dengan nomor 087811132004

---

## Preview Visual

### Review Card (Google Style)
```text
┌─────────────────────────────────────────┐
│  🔴 A  Andi Pratama                     │
│  ★★★★★  •  3 hari lalu                  │
│  📍 Studio Rental                       │
│                                         │
│  "Tempatnya nyaman, sound system        │
│   bagus, recommended banget!"           │
│                                         │
└─────────────────────────────────────────┘
```

### Futuristic Elements
- Neon red glow pada borders dan buttons
- Animated gradient backgrounds
- Glassmorphism cards dengan blur effect
- Cyberpunk-inspired grid pattern
- Glowing text effects untuk headings

