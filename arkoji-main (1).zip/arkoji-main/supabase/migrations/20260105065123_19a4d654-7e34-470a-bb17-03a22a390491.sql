-- Fix Security Definer View issue by recreating it with security_invoker = true
DROP VIEW IF EXISTS public.payment_settings_public;

CREATE VIEW public.payment_settings_public 
WITH (security_invoker = true)
AS
SELECT 
  id,
  payment_type,
  payment_name,
  qris_image_url,
  is_active
FROM public.payment_settings
WHERE is_active = true;

-- Grant access to the view
GRANT SELECT ON public.payment_settings_public TO anon, authenticated;

-- Add RLS policy for the view to work
CREATE POLICY "Anyone can view payment settings public view"
ON public.payment_settings
FOR SELECT
TO anon, authenticated
USING (is_active = true);