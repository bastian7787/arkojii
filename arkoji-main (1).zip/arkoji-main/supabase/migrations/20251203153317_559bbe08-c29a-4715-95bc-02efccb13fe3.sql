-- Fix bookings table: ensure only admins can SELECT (drop and recreate to be safe)
DROP POLICY IF EXISTS "Only admins can view bookings" ON public.bookings;
DROP POLICY IF EXISTS "Anyone can view bookings" ON public.bookings;

CREATE POLICY "Only admins can view bookings" 
ON public.bookings 
FOR SELECT 
TO authenticated
USING (is_admin(auth.uid()));

-- Fix profiles table: ensure only authenticated users can view their own profile
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;

CREATE POLICY "Users can view own profile" 
ON public.profiles 
FOR SELECT 
TO authenticated
USING (auth.uid() = id);

-- Add INSERT policy for profiles (for new user registration)
DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;

CREATE POLICY "Users can insert own profile"
ON public.profiles
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);