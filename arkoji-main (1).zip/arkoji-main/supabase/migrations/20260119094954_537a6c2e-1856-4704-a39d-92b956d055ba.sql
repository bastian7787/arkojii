-- Drop existing view and recreate with full account number
DROP VIEW IF EXISTS public.payment_settings_public;

CREATE VIEW public.payment_settings_public 
WITH (security_invoker = true)
AS
SELECT 
  id,
  is_active,
  payment_type,
  payment_name,
  account_number,  -- Show full account number, not masked
  account_holder,
  qris_image_url
FROM public.payment_settings
WHERE is_active = true;