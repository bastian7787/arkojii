-- Make payment-proofs bucket public so admin can view payment proofs
UPDATE storage.buckets SET public = true WHERE id = 'payment-proofs';