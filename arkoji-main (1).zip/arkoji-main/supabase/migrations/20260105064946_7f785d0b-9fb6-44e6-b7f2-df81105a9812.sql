-- 1. Fix payment_settings: Create a view for public access that hides sensitive data
CREATE OR REPLACE VIEW public.payment_settings_public AS
SELECT 
  id,
  payment_type,
  payment_name,
  qris_image_url,
  is_active
FROM public.payment_settings
WHERE is_active = true;

-- Grant access to the view
GRANT SELECT ON public.payment_settings_public TO anon, authenticated;

-- Update the payment_settings RLS policy to only allow admin access
DROP POLICY IF EXISTS "Anyone can view active payment settings" ON public.payment_settings;

-- 2. Fix bookings: Add INSERT policy for public users to create bookings
CREATE POLICY "Anyone can create bookings"
ON public.bookings
FOR INSERT
TO anon, authenticated
WITH CHECK (true);

-- 3. Fix storage: Update payment-proofs bucket policies
-- First, make the bucket private
UPDATE storage.buckets 
SET public = false 
WHERE id = 'payment-proofs';

-- Drop existing overly permissive policies
DROP POLICY IF EXISTS "Anyone can upload payment proofs" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can view payment proofs" ON storage.objects;
DROP POLICY IF EXISTS "Admins can delete payment proofs" ON storage.objects;

-- Create more secure storage policies
-- Allow anyone to upload (needed for booking flow) but with path restrictions
CREATE POLICY "Users can upload payment proofs"
ON storage.objects
FOR INSERT
TO anon, authenticated
WITH CHECK (
  bucket_id = 'payment-proofs' AND
  (storage.foldername(name))[1] = 'proofs'
);

-- Only admins can view payment proofs
CREATE POLICY "Admins can view payment proofs"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'payment-proofs' AND
  public.is_admin(auth.uid())
);

-- Admins can delete payment proofs
CREATE POLICY "Admins can delete payment proofs"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'payment-proofs' AND
  public.is_admin(auth.uid())
);