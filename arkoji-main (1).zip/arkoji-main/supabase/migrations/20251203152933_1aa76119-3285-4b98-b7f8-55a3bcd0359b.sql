-- Drop existing policy that allows anyone to view bookings
DROP POLICY IF EXISTS "Anyone can view bookings" ON public.bookings;

-- Create new policy that only allows admins to view bookings
CREATE POLICY "Only admins can view bookings" 
ON public.bookings 
FOR SELECT 
USING (is_admin(auth.uid()));