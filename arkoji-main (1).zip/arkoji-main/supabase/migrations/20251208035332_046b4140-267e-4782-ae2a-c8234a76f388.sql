-- Add payment columns to bookings table
ALTER TABLE public.bookings
ADD COLUMN payment_method text,
ADD COLUMN payment_status text NOT NULL DEFAULT 'unpaid',
ADD COLUMN payment_amount numeric,
ADD COLUMN payment_proof_url text,
ADD COLUMN paid_at timestamp with time zone;

-- Create payment_settings table for storing QRIS images and payment options
CREATE TABLE public.payment_settings (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  payment_type text NOT NULL,
  payment_name text NOT NULL,
  account_number text,
  account_holder text,
  qris_image_url text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.payment_settings ENABLE ROW LEVEL SECURITY;

-- RLS policies for payment_settings
CREATE POLICY "Anyone can view active payment settings"
ON public.payment_settings
FOR SELECT
USING (is_active = true);

CREATE POLICY "Admins can manage payment settings"
ON public.payment_settings
FOR ALL
USING (is_admin(auth.uid()))
WITH CHECK (is_admin(auth.uid()));

-- Add trigger for updated_at
CREATE TRIGGER update_payment_settings_updated_at
BEFORE UPDATE ON public.payment_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();