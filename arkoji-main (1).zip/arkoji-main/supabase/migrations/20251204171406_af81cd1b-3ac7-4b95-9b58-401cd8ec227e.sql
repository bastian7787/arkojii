-- Remove public INSERT policy - only edge function with service role can insert now
DROP POLICY IF EXISTS "Public can create bookings" ON public.bookings;
DROP POLICY IF EXISTS "Anyone can create bookings" ON public.bookings;

-- Add policy for service role (edge functions) - this is implicit but let's be explicit
-- Service role bypasses RLS, so no policy needed for it