-- Add another_service to booking_type enum
ALTER TYPE booking_type ADD VALUE IF NOT EXISTS 'another_service';