
-- Allow anyone to insert reviews (public submission)
CREATE POLICY "Anyone can submit reviews"
ON public.reviews
FOR INSERT
WITH CHECK (true);
