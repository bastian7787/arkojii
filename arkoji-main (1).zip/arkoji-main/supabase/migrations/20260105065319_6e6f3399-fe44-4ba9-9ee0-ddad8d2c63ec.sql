-- Add proper RLS for the view's underlying table access
-- The view needs a policy to access payment_settings but only expose masked data

-- Create a new RLS policy specifically for the view access pattern
CREATE POLICY "Public can read active payment settings for view"
ON public.payment_settings
FOR SELECT
TO anon, authenticated
USING (is_active = true);