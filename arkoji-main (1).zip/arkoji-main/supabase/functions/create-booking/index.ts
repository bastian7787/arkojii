import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.76.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Simple in-memory rate limiting (resets on function restart)
const rateLimitMap = new Map<string, { count: number; resetTime: number }>();
const RATE_LIMIT = 5; // Max 5 bookings per IP per hour
const RATE_WINDOW = 60 * 60 * 1000; // 1 hour in milliseconds

function isRateLimited(ip: string): boolean {
  const now = Date.now();
  const record = rateLimitMap.get(ip);
  
  if (!record || now > record.resetTime) {
    rateLimitMap.set(ip, { count: 1, resetTime: now + RATE_WINDOW });
    return false;
  }
  
  if (record.count >= RATE_LIMIT) {
    return true;
  }
  
  record.count++;
  return false;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const clientIP = req.headers.get("x-forwarded-for")?.split(",")[0] || 
                     req.headers.get("x-real-ip") || 
                     "unknown";

    // Check rate limit
    if (isRateLimited(clientIP)) {
      return new Response(
        JSON.stringify({ error: "Terlalu banyak permintaan. Silakan coba lagi nanti." }),
        { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const body = await req.json();
    console.log("Received booking request:", JSON.stringify(body, null, 2));

    const { 
      customer_name, 
      customer_phone, 
      customer_email, 
      booking_type, 
      booking_date, 
      start_time, 
      end_time, 
      notes,
      payment_method,
      payment_amount,
      payment_proof_url
    } = body;

    // Validate required fields
    if (!customer_name || !customer_phone || !booking_type || !booking_date || !start_time || !end_time) {
      return new Response(
        JSON.stringify({ error: "Data booking tidak lengkap" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate field lengths
    if (customer_name.length > 100 || customer_phone.length > 20 || (customer_email && customer_email.length > 255)) {
      return new Response(
        JSON.stringify({ error: "Data melebihi batas karakter" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate phone number format (basic validation)
    const phoneRegex = /^[0-9+\-\s()]{8,20}$/;
    if (!phoneRegex.test(customer_phone)) {
      return new Response(
        JSON.stringify({ error: "Format nomor telepon tidak valid" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate email if provided
    if (customer_email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(customer_email)) {
        return new Response(
          JSON.stringify({ error: "Format email tidak valid" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    // Validate booking type
    const validTypes = ["vocal_class", "studio_rental", "music_production", "another_service", "other_service", "recording"];
    if (!validTypes.includes(booking_type)) {
      return new Response(
        JSON.stringify({ error: "Tipe booking tidak valid" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate payment proof for studio rental
    if (booking_type === "studio_rental" && !payment_proof_url) {
      return new Response(
        JSON.stringify({ error: "Bukti pembayaran diperlukan untuk studio rental" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create Supabase client with service role
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Check for conflicting bookings
    const { data: existingBookings, error: checkError } = await supabase
      .from("bookings")
      .select("start_time, end_time")
      .eq("booking_date", booking_date)
      .eq("booking_type", booking_type)
      .neq("status", "cancelled");

    if (checkError) {
      console.error("Check conflict error:", checkError);
      return new Response(
        JSON.stringify({ error: "Gagal memeriksa ketersediaan" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check if time slot is available
    const hasConflict = existingBookings?.some((booking: { start_time: string; end_time: string }) => {
      const existingStart = booking.start_time;
      const existingEnd = booking.end_time;
      return (
        (start_time >= existingStart && start_time < existingEnd) ||
        (end_time > existingStart && end_time <= existingEnd) ||
        (start_time <= existingStart && end_time >= existingEnd)
      );
    });

    if (hasConflict) {
      return new Response(
        JSON.stringify({ error: "Waktu yang dipilih sudah dibooking. Silakan pilih waktu lain." }),
        { status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Build booking data
    const bookingData: Record<string, any> = {
      customer_name: customer_name.trim(),
      customer_phone: customer_phone.trim(),
      customer_email: customer_email?.trim() || null,
      booking_type,
      booking_date,
      start_time,
      end_time,
      notes: notes?.trim() || null,
      status: "pending"
    };

    // Add payment fields if provided
    if (payment_method) {
      bookingData.payment_method = payment_method;
    }
    if (payment_amount) {
      bookingData.payment_amount = payment_amount;
    }
    if (payment_proof_url) {
      bookingData.payment_proof_url = payment_proof_url;
      bookingData.payment_status = "paid";
      bookingData.paid_at = new Date().toISOString();
    }

    // Insert booking
    const { data, error } = await supabase
      .from("bookings")
      .insert(bookingData)
      .select()
      .single();

    if (error) {
      console.error("Booking error:", error);
      return new Response(
        JSON.stringify({ error: "Gagal membuat booking" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Booking created successfully:", data.id);

    return new Response(
      JSON.stringify({ success: true, booking: data }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error) {
    console.error("Error:", error);
    return new Response(
      JSON.stringify({ error: "Terjadi kesalahan" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
