import { serve } from "https://deno.land/std@0.190.0/http/server.ts";


const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface BookingNotificationRequest {
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  bookingType: string;
  bookingDate: string;
  startTime: string;
  endTime: string;
  status: string;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const {
      customerName,
      customerEmail,
      customerPhone,
      bookingType,
      bookingDate,
      startTime,
      endTime,
      status,
    }: BookingNotificationRequest = await req.json();

    console.log("Sending booking notification email to:", customerEmail);

    const bookingTypeLabels: Record<string, string> = {
      vocal_class: "Kelas Vokal",
      studio_rental: "Sewa Studio",
      music_production: "Produksi Musik",
    };

    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${Deno.env.get("RESEND_API_KEY")}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "Arkoji Studio <onboarding@resend.dev>",
        to: [customerEmail],
        subject: `Booking ${status === "confirmed" ? "Dikonfirmasi" : "Dibatalkan"} - Arkoji Studio`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #333; border-bottom: 3px solid #9b87f5; padding-bottom: 10px;">
              Arkoji Studio
            </h1>
            
            <div style="margin: 30px 0; padding: 20px; background-color: ${
              status === "confirmed" ? "#d4f4dd" : "#ffd4d4"
            }; border-radius: 8px;">
              <h2 style="color: ${status === "confirmed" ? "#16a34a" : "#dc2626"}; margin-top: 0;">
                ${status === "confirmed" ? "✅ Booking Dikonfirmasi!" : "❌ Booking Dibatalkan"}
              </h2>
            </div>

            <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="color: #333; margin-top: 0;">Detail Booking:</h3>
              <table style="width: 100%; border-collapse: collapse;">
                <tr>
                  <td style="padding: 8px 0; color: #666;">Nama:</td>
                  <td style="padding: 8px 0; font-weight: bold;">${customerName}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;">Telepon:</td>
                  <td style="padding: 8px 0; font-weight: bold;">${customerPhone}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;">Jenis Booking:</td>
                  <td style="padding: 8px 0; font-weight: bold;">${bookingTypeLabels[bookingType] || bookingType}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;">Tanggal:</td>
                  <td style="padding: 8px 0; font-weight: bold;">${new Date(bookingDate).toLocaleDateString("id-ID", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;">Waktu:</td>
                  <td style="padding: 8px 0; font-weight: bold;">${startTime} - ${endTime}</td>
                </tr>
              </table>
            </div>

            ${
              status === "confirmed"
                ? `
            <div style="margin: 30px 0; padding: 20px; background-color: #fff3cd; border-left: 4px solid #ffc107; border-radius: 4px;">
              <p style="margin: 0; color: #856404;">
                <strong>Catatan Penting:</strong><br>
                Harap datang 10 menit sebelum waktu booking Anda. Jika ada perubahan jadwal, silakan hubungi kami via WhatsApp.
              </p>
            </div>
            `
                : `
            <div style="margin: 30px 0; padding: 20px; background-color: #f8d7da; border-left: 4px solid #dc2626; border-radius: 4px;">
              <p style="margin: 0; color: #721c24;">
                Booking Anda telah dibatalkan. Jika Anda ingin membuat booking baru atau memiliki pertanyaan, silakan hubungi kami.
              </p>
            </div>
            `
            }

            <div style="margin: 30px 0; text-align: center;">
              <a href="https://wa.me/6282180007130" 
                 style="display: inline-block; padding: 12px 30px; background-color: #25D366; color: white; text-decoration: none; border-radius: 6px; font-weight: bold;">
                💬 Hubungi via WhatsApp
              </a>
            </div>

            <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; font-size: 14px;">
              <p><strong>Arkoji Studio</strong></p>
              <p>Jl. Bangka VIII A No.4, RT.1/RW.12<br>
              Pela Mampang, Kec. Mampang Prpt.<br>
              Jakarta Selatan 12720</p>
              <p>Telepon: 0821-8000-7130</p>
            </div>
          </div>
        `,
      }),
    });

    const data = await emailResponse.json();

    if (!emailResponse.ok) {
      throw new Error(data.message || "Failed to send email");
    }

    console.log("Email sent successfully:", data);

    return new Response(JSON.stringify(data), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error sending booking notification:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
